package com.example.testspringbootdocker;

import org.junit.jupiter.api.Test;
import org.apache.commons.lang3.StringUtils;

import org.springframework.web.client.RestTemplate;

import static org.assertj.core.api.Assertions.assertThat;

class TestSpringBootDockerApplicationTests {

	public String getBaseUrl(){
        if(StringUtils.isNotEmpty(System.getProperty("base.url"))||StringUtils.isNotBlank(System.getProperty("base.url"))) {
            return System.getProperty("base.url");
        }else{
            return "http://localhost:8080/";
        }
    }

	@Test
	public void returnDefaultMessage() throws Exception {
		RestTemplate restTemplate = new RestTemplate();
		assertThat(restTemplate.getForObject(getBaseUrl(),
				String.class)).contains("Hello, World");
	}

	@Test
	public void returnGreetingDefaultMessage() throws Exception {
		RestTemplate restTemplate = new RestTemplate();
		assertThat(restTemplate.getForObject(getBaseUrl() + "greeting",
				String.class)).contains("Nice to meet you!");
	}

}
