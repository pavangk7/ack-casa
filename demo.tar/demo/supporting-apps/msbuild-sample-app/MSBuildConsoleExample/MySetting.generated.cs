 using System;
 namespace MSBuildConsoleExample {

  public class MySetting {
    public readonly static string  Greeting = "Hello World!";
  }

}