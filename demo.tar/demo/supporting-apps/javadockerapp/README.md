# Reference Pipeline for Containerized Java Application

This project is a reference of a end to end CI pipeline for sample containerized Java application hosted in AWS EKS. 

<span style="color:red">Note: The source code for this application is not meant as a reference for writing good/secure code and is purely used to demonstrate the pipeline.</span>

## Table of contents:

- [Pipeline](#pipeline)
- [Source Code](#source-code)

## Pipeline
Pipeline is defined in [.gitlab-ci.yml](.gitlab-ci.yml) and it leverages templates in the inner-sourced project [SHIP-HATS Templates](https://gts.gitlab-dedicated.systems/templates/ship-hats-templates).

The application above consists of 3 services:
- shopfront: front-end with UI and which consumes data from the 2 services below
- stockmanager: service that exposes stock data via REST-like endpoint
- productcatalogue: service that exposes product data via REST-like endpoint

The CI pipeline documented here involves a single pipeline that covers all services. This would imply the same build and release cycle for all 3 services. Alternatively, one can also consider having a separate CI pipeline for each service.  

For pre-requisites, please refer to [Common Pre-requisites to Using Reference Pipelines](https://gts.gitlab-dedicated.systems/groups/ctmo/-/wikis/Common-Pre-requisites-to-Using-Reference-Pipelines-(WIP)).

For CD approaches, please refer to [Gitlab CD Approaches](https://sgts.gitlab-dedicated.com/groups/wog/gvt/ctmo/reference-pipelines/-/wikis/Gitlab-CD-Approaches)

### Version Management
1. Each build is considered as a potential release so maven snapshots are not used.
2. For consistency, the form X.Y.Z is used for versioning as npm version follows semantic versioning. 
3. Z is the Bamboo plan build number, which can be derived from the predefined gitlab variable CI_PIPELINE_IID.   
4. For every build, the following is used to set the new version number for each service before compilation/packaging (see [version_all.sh](version_all.sh))

## Source Code
This is a clone of the [oreilly-docker-java-shopping](https://github.com/danielbryantuk/oreilly-docker-java-shopping.git) in GitHub. Source code has been slightly modified so that it can be used to demonstrate the pipeline.

The O'Reilly mini book (Containerizing Continuous Delivery in Java) mentioned below can be found in this repository. 

The original content of the README will continue from here:

### oreilly-docker-java-shopping
This repo contains code samples from my O'Reilly minibook ["Containerizing Continuous Delivery in Java: Docker Integration for Build Pipelines and Application Architecture"](https://www.nginx.com/resources/library/containerizing-continuous-delivery-java/).

This README is intended to provide high-level guidance of the project, and detailed instructions can be found in the accompanying book.

### Project Structure

* ci-vagrant
 * Installation files that build a Jenkins instance that is ready for experimenting with the examples contained within the book.
 * Currently the installation is undertaken using [Vagrant](https://www.vagrantup.com/) and Oracle's [VirtualBox](https://www.virtualbox.org/)
 * Once Vagrant and VirtualBox are installed locally, the Jenkins box can be built from this directory using the `vagrant up` command
* functional-e2e-tests
 * Simple examples of functional end-to-end tests that use JUnit and [REST-assured](http://rest-assured.io/) to test the DJShopping application
* performance-e2e-tests
 * Simple examples of performance/load end-to-end tests that use [Gatling](http://gatling.io/#/) with SBT and Scala
* shopfront
 * The 'shopfront' microservice of the DJShopping example application that provides the primary entry point for the end-user (both Web UI and API-driven)
* productcatalogue
  * The 'product catalogue' microservice of the DJShopping example application, which provides product details like name and price
* stockmanager
  * The 'stock manager' microservice of the DJShopping example application, which provides stock information, such as SKU and quantity
* build_all.sh
  * Convenience shell script for triggering Maven builds of all of the application microservices. This script does not build the associated Docker images, but the minibook contains instructions for doing so, alongside the suggestion that the resulting Docker images are pushed to your own DockerHub account
* build_all_and_publish_dockerhub.yml
  * Convenience build and publish shell script for triggering Maven builds of all of the application microservices, building an associated Docker image, and (if successful) a push of the image to DockerHub. If you wish to use this script you will have to create a DockerHub account and substitute the existing account details ('danielbryantuk') with your own.
* docker-compose.yml
 * [Docker Compose](https://docs.docker.com/compose/) file that starts all of the DJShopping application microservice containers. Note that if you push your own version of the Docker images to your DockerHub account you will have to change the image names details within this file to run these (i.e. remove the 'danielbryantuk' account name)
 * Run the file via the command `docker-compose up`
* docker-compose-build.yml
  * [Docker Compose](https://docs.docker.com/compose/) file that contains the build configuration of the DJShopping application microservices.
  * Build the Docker images via the command `docker-compose -f docker-compose-build.yml build`
  * Build and run the Docker images via the command `docker-compose -f docker-compose-build.yml up --build`

### Example Jenkins Pipelines

Once the Jenkins instance has been built and configured as specified in the accompanying minibook, and the DJShopping build items have been configured and run, it will be possible to create Jenkins Pipeline examples for running end-to-end tests. The examples contained within the book are included here for reference:

#### Single Service Initialisation Test

```
node {
    stage ('Successful startup check') {
        docker.image('danielbryantuk/djshopfront').withRun('-p 8010:8010') {
            timeout(time: 30, unit: 'SECONDS') {
                waitUntil {
                    def r = sh script: 'curl -s http://localhost:8010/health | grep "UP"', returnStatus: true
                    return (r == 0);
                }
            }
        }
    }
}
```

#### End-to-end Initialisation Test

```
node {
    stage ('build') {
        git url: 'https://github.com/danielbryantuk/oreilly-docker-java-shopping.git'
        // conduct other build tasks
    }

    stage ('end-to-end tests') {
        timeout(time: 60, unit: 'SECONDS') {
            try {
                sh 'docker-compose up -d'
                waitUntil { // application is up
                    def r = sh script: 'curl -s http://localhost:8010/health | grep "UP"', returnStatus: true
                    return (r == 0);
                }

                // conduct main test here
                sh 'curl http://localhost:8010 | grep "Docker Java"'

            } finally {
                sh 'docker-compose stop'
            }
        }
    }

    stage ('deploy') {
        // deploy the containers/application here
    }
}
```

#### End-to-end Functional Tests
```
node {
    stage ('build') {
        git url: 'https://github.com/danielbryantuk/oreilly-docker-java-shopping.git'
        // conduct other build tasks
    }

    stage ('end-to-end tests') {
        timeout(time: 60, unit: 'SECONDS') {
            try {
                sh 'docker-compose up -d'
                waitUntil { // application is up
                    def r = sh script: 'curl -s http://localhost:8010/health | grep "UP"', returnStatus: true
                    return (r == 0);
                }

                // conduct main test here
                sh 'cd functional-e2e-tests && mvn clean verify'

            } finally {
                sh 'docker-compose stop'
            }
        }
    }

    stage ('deploy') {
        // deploy the containers/application here
    }
}
```
