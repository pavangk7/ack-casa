# SHIP-HATS Templates

SHIP-HATS Templates consist of a list of sample example pipeline templates using the basic building blocks that support common usage of job required by tenants' pipelines.

# Table of Contents:
1. [Azcli-Invoke](#example-azcli-invoke)
2. [Awscli-Invoke](#example-awscli-invoke)
3. [Kubectl-Invoke](#example-kubectl-invoke)
4. [Aws-Secret-Retrieval](#example-aws-secret-retrieval)
5. [Nexus-Docker-Pull-And-Scan](#example-nexus-docker-pull-and-scan)
6. [Private-Registry-Docker-Push](#example-private-registry-docker-push)
7. [Nexus-Pull-And-Publish-MVN](#example-nexus-pull-and-publish-mvn)
8. [Nexus-Pull-Scan-And-Publish-NPM](#example-nexus-pull-scan-and-publish-npm)
9. [Nexus-Pull-and-Publish-NuGet](#example-nexus-pull-and-publish-nuget)
10. [Nexus-Pull-and-Publish-NuGet-Windows](#example-nexus-pull-and-publish-nuget-windows)
11. [Robot-Framework-Test-And-Report](#example-robot-framework-test-and-report)
12. [Aquasec-Trivy-Scan-File](#example-aquasec-trivy-scan-file)
13. [Aquasec-Trivy-Scan-Private-Repo](#example-aquasec-trivy-scan-private-repo)
14. [Container-Signing](#example-container-signing)
15. [Blob-Signing](#example-blob-signing)
16. [Pcloudy-Test-App](#example-pcloudy-test-app)
17. [Pcloudy-Test-Browser](#example-pcloudy-test-browser)
18. [Readiness-Check-For-Docker-Service](#example-readiness-check-for-docker-service)
19. [Fod-Sast](#example-fod-sast)
20. [Fod-Dast](#example-fod-dast)
21. [Fod-Sast-MSBuild](#example-fod-sast-msbuild)
22. [Fod-Sast-Generate-Report](#example-fod-sast-generate-report)
23. [Fod-Dast-Generate-Report](#example-fod-dast-generate-report)
24. [Maven-Artefact-Checksum-Verification](#example-maven-artefact-checksum-verification)
25. [Postman-Test-And-Report](#example-postman-test-and-report)
26. [GitLab-Release-Management](#example-gitlab-release-management)

## Example: [Azcli-Invoke](Azcli-Invoke.yml)

### Target user:

The example shows how to do the following in a GitLab pipeline:

* Restarting an Azure App Service Web App using Azure CLI
* Waiting for Web App to be ready by querying the URL and searching for a given text in a loop for 120s

### Demonstrating:
* .invoke-azcli-commands-with-serviceprincipal from [templates/.gitlab-ci-azure.yml](../templates#template-invoke-azcli-commands-with-serviceprincipal)
* .wait-for-app-and-assert-text from [templates/.gitlab-ci-check-app-readiness.yml)](../templates#template-wait-for-app-and-assert-text)

## Example: [Awscli-Invoke](Awscli-Invoke.yml)

### Target user:

The example shows how to do the following in a GitLab pipeline:

* Upload a text file to S3 bucket using AWS CLI

### Demonstrating:
* .invoke-awscli-commands-with-assume-role from [templates/.gitlab-ci-aws.yml](../templates#template-invoke-awscli-commands-with-assumerole)

## Example: [Kubectl-Invoke](Kubectl-Invoke.yml)

### Target user:

The example shows how to do the following in a GitLab pipeline:

* Apply a sample hello world manifest to an AWS EKS cluster.

### Demonstrating:
* .invoke-kubectlupdateconfig from [templates/.gitlab-ci-aws.yml](../templates#template-invoke-kubectlupdateconfig)

### Sample-apps:
* [supporting-apps/helloworld-manifest](../supporting-apps/helloworld-manifest)

## Example: [Aws-Secret-Retrieval](Aws-Secret-Retrieval.yml)

### Target user:

The example shows how to do the following in a GitLab pipeline:

*  Retrieve a sample secret key from aws secret manager, and parse using jq.

### Demonstrating:
* .invoke-awssecretretrieval from [templates/.gitlab-ci-aws.yml](../templates#template-invoke-awssecretretrieval) 

## Example: [Nexus-Docker-Pull-And-Scan](Nexus-Docker-Pull-And-Scan.yml)

### Target user:

The example covers the following scenarios:

* Pulling a docker image via SHIP's Nexus Repository `docker-proxy`
* Pulling a docker image via SHIP's Nexus Repository `docker-hosted`
* Scan a docker image tar using Nexus IQ

Each scenario shows how to do the following in a GitLab pipeline:

* Pull the docker image from the target docker registry
* Run Nexus iq scan on tar after pull.

### Demonstrating: 
* .pull-docker-image-fr-proxy-nexus-repo from [templates/.gitlab-ci-nexus-docker-pull.yml](../templates#template-pull-docker-image-fr-proxy-nexus-repo)
* .pull-docker-image-fr-hosted-nexus-repo from [templates/.gitlab-ci-nexus-docker-pull.yml](../templates#template-pull-docker-image-fr-hosted-nexus-repo)
* .nexus-iq-scan from [templates/.gitlab-ci-nexus-iq-scan.yml](../templates#template-nexus-iq-scan)

## Example: [Private-Registry-Docker-Push](Private-Registry-Docker-Push.yml)

### Target user:

This example shows how to do the following in a GitLab pipeline:

* Build a docker image and export as output.tar.
* Publish output.tar to a private registry, for e.g., SHIP's Nexus Repository.

### Demonstrating: 
* .build-docker-image from [templates/.gitlab-ci-docker-build.yml](../templates#template-build-docker-image)
* .push-docker-image-to-private-registry from [templates/.gitlab-ci-docker-push.yml](../templates#template-push-docker-image-to-private-registry)

### Sample-apps:
* [supporting-apps/simple-docker-image](../supporting-apps/simple-docker-image)

## Example: [Nexus-Pull-And-Publish-MVN](Nexus-Pull-And-Publish-MVN.yml)

### Target user:

This example shows how to do the following in a GitLab pipeline:

* Perform Sonarqube scan on source code to detect bugs, code smells, and security vulnerabilities.
* Create SAST Gitlab report for Sonarqube scan.
* Publish an artefact to a hosted Maven repository in SHIP's Nexus Repository.

### Demonstrating: 
* .sonarqube-scan-maven from [templates/.gitlab-ci-sonarqube.yml](../templates#template-sonarqube-scan-maven)
* .sonarqube-output-report from [templates/.gitlab-ci-sonarqube.yml](../templates#template-sonarqube-output-report)
* .publish-maven-artefact from [templates/.gitlab-ci-publish-to-nexus.yml](../templates#template-publish-maven-artefact)


### Sample-apps:
* [supporting-apps/maven-simple-app](../supporting-apps/maven-simple-app)
* [ctmo/reference-pipelines/netapp](https://sgts.gitlab-dedicated.com/WOG/GVT/ctmo/reference-pipelines/netapp)

## Example: [Nexus-Pull-Scan-And-Publish-NPM](Nexus-Pull-Scan-And-Publish-NPM.yml)

### Target user:

This example shows how to do the following in a GitLab pipeline:

* Pull npm dependency library packages (based on package-lock.json) from SHIP's Nexus Repository.
* Perform depcheck to identify unused dependencies.
* Perform Sonarqube scan on source code to detect bugs, code smells, and security vulnerabilities.
* Create SAST Gitlab report for Sonarqube scan.
* Perform Nexus IQ Scan.
* Publish an artefact to a hosted npm repository in SHIP's Nexus Repository.

### Demonstrating:
* .configure-npm-for-nexus from [templates/.gitlab-ci-nexus-configure.yml](../templates#template-configure-npm-for-nexus)
* .npm-depcheck from [templates/.gitlab-ci-nodejs-common.yml](../templates#template-npm-depcheck)
* .sonarqube-scan from [templates/.gitlab-ci-sonarqube.yml](../templates#template-sonarqube-scan)
* .sonarqube-output-report from [templates/.gitlab-ci-sonarqube.yml](../templates#template-sonarqube-output-report)
* .nexus-iq-scan from [templates/.gitlab-ci-nexus-iq-scan.yml](../templates#template-nexus-iq-scan)
* .publish-nodejs-artefact from [templates/.gitlab-ci-publish-to-nexus.yml](../templates#template-publish-nodejs-artefact)

### Sample-apps:
* [supporting-apps/nodejs-simple-library](../supporting-apps/nodejs-simple-library)
* [ctmo/reference-pipelines/nodetsapp](https://sgts.gitlab-dedicated.com/WOG/GVT/ctmo/reference-pipelines/nodetsapp)

## Example: [Nexus-Pull-And-Publish-NuGet](Nexus-Pull-And-Publish-NuGet.yml)

### Target user:

This example shows how to do the following in a GitLab pipeline:

* Restore a package with dotNet CLI from SHIP's Nexus Repository.
* Perform Sonarqube scan on source code to detect bugs, code smells, and security vulnerabilities.
* Create SAST Gitlab report for Sonarqube scan.
* Publish an artefact to a hosted nuget repository in SHIP's Nexus Repository using dotNet CLI

### Demonstrating:
* the use of variables from [templates/vars/.gitlab-ci-nuget-vars.yml](../templates/vars/.gitlab-ci-nuget-vars.yml)
* .publish-nuget-artefact-using-dotnet-cli from [templates/.gitlab-ci-publish-to-nexus.yml](../templates#template-publish-nuget-artefact-using-dotnet-cli)
* .sonarqube-scan-dotnet from [templates/.gitlab-ci-sonarqube.yml](../templates#template-sonarqube-scan-dotnet)
* .sonarqube-output-report from [templates/.gitlab-ci-sonarqube.yml](../templates#template-sonarqube-output-report)
* .configure-publish-nuget-for-nexus-using-dotnet-cli from [templates/.gitlab-ci-nexus-configure.yml](../templates#template-configure-publish-nuget-for-nexus-using-dotnet-cli)

### Sample-apps:
* [supporting-apps/dotNet-core-console-project](../supporting-apps/dotNet-core-console-project)

## Example: [Nexus-Pull-And-Publish-NuGet-Windows](Nexus-Pull-And-Publish-NuGet-Windows.yml)

### Target user:

This example shows how to do the following in a GitLab pipeline:

* Restore a package with NuGet CLI (GitLab runners on Windows) from SHIP's Nexus Repository.
* Perform Sonarqube scan on source code to detect bugs, code smells, and security vulnerabilities.
* Create SAST Gitlab report for Sonarqube scan.
* Publish an artefact to a hosted nuget repository in SHIP's Nexus Repository using NuGet CLI (GitLab runners on Windows).

### Demonstrating:
* the use of variables from [templates/vars/.gitlab-ci-nuget-vars.yml](../templates/vars/.gitlab-ci-nuget-vars.yml)
* .publish-nuget-artefact-using-nuget-cli from [templates/.gitlab-ci-publish-to-nexus.yml](../templates#template-publish-nuget-artefact-using-nuget-cli)
* .sonarqube-scan-dotnet-framework from [templates/.gitlab-ci-sonarqube.yml](../templates#template-sonarqube-scan-dotnet-framework)
* .sonarqube-output-report from [templates/.gitlab-ci-sonarqube.yml](../templates#template-sonarqube-output-report)
* .configure-publish-nuget-for-nexus-using-nuget-cli from [templates/.gitlab-ci-nexus-configure.yml](../templates#template-configure-publish-nuget-for-nexus-using-nuget-cli)

### Sample-apps:
* [supporting-apps/dotNet-framework-console-project](../supporting-apps/dotNet-framework-console-project)

## Example: [Robot-Framework-Test-And-Report](Robot-Framework-Test-And-Report.yml)

This example shows how to do following in a Gitlab pipeline:

* Run robot test from defined test script
* Generate consolidated report from different tests

### Demonstrating:
* .run-robot-test from [templates/.gitlab-ci-run-test.yml](../templates#template-run-robot-test)
* .generate-robot-consolidated-report from [templates/.gitlab-ci-create-report.yml](../templates#template-generate-robot-consolidated-report)

### Sample-apps:
* [supporting-apps/robot-framework-testsuite](../supporting-apps/robot-framework-testsuite/)
* [ctmo/reference-pipelines/nodetsapp](https://sgts.gitlab-dedicated.com/WOG/GVT/ctmo/reference-pipelines/nodetsapp)

## Example: [Aquasec-Trivy-Scan-File](Aquasec-Trivy-Scan-File.yml)

### Target user:

This example shows how to do the following in a GitLab pipeline:

* Build a docker image and export as output.tar.
* Perform an Aquasec Trivy scan on an image in a .tar or .tar.gz format and generate a Gitlab-compatible report artifact for the UI.

### Demonstrating:
* .build-docker-image from [templates/.gitlab-ci-docker-build.yml](../templates#template-build-docker-image)
* .trivy-scan from [templates/.gitlab-ci-aquasec-trivy-scan.yml](../templates#template-trivy-scan)

### Sample-apps:
* [supporting-apps/aquasec-trivy-scan](../supporting-apps/aquasec-trivy-scan)

## Example: [Aquasec-Trivy-Scan-Private-Repo](Aquasec-Trivy-Scan-Private-Repo.yml)

### Target user:

This example shows how to do the following in a GitLab pipeline:

* Perform an Aquasec Trivy scan on an image from a remote private image repository, and generate a Gitlab-compatible report artifact for the UI.

### Demonstrating:
* .trivy-scan from [templates/.gitlab-ci-aquasec-trivy-scan.yml](../templates#template-trivy-scan)

## Example: [Container-Signing](Container-Signing.yml)

### Target user:

This example shows how to do the following in a GitLab pipeline:
* Build an image and push to a container registry.
* Perform container signing, verification in a container registry.
* This pipeline will generate an artifact which contain the pub key for verification.
* Copy a docker image from GitLab Container Registry to AWS ECR.
* Clean up the image and its relative cosign signature from GitLab Container Registry.

### Demonstrating:
* .build-and-push-docker-image from [templates/.gitlab-ci-docker-build.yml](../templates#template-build-and-push-docker-image)
* .sign-container from [templates/.gitlab-ci-container-signing.yml](../templates#template-sign-container)
* .verify-container from [templates/.gitlab-ci-container-signing.yml](../templates#template-verify-container)
* .invoke-ecr-token-retrieval from [templates/.gitlab-ci-aws.yml](../templates#invoke-ecr-token-retrieval) 
* .copy-docker-image-from-one-remote-registry-to-another from [templates/.gitlab-ci-docker-copy.yml](../templates#template-copy-docker-image-from-one-remote-registry-to-another)
* .delete-gitlab-cr-image from [templates/.gitlab-ci-docker-delete.yml](../templates#template-delete-gitlab-cr-image)

### Sample-apps:
* [supporting-apps/simple-docker-image](../supporting-apps/simple-docker-image)

## Example: [Blob-Signing](Blob-Signing.yml)

### Target user:

This example shows how to do the following in a GitLab pipeline:

* Perform standard file signing and verification.
* This pipeline will generate an artifact which contain standard files, pub key and signature for verification.

### Demonstrating:
* .sign-artifact from [templates/.gitlab-ci-blob-signing.yml](../templates#template-sign-artifact)
* .verify-artifact from [templates/.gitlab-ci-blob-signing.yml](../templates#template-verify-artifact)

### Sample-apps:
* [supporting-apps/helloworld-manifest](../supporting-apps/helloworld-manifest)

## Example: [Pcloudy-Test-App](Pcloudy-Test-App.yml)

### Target user:

This example shows how to do the following in a Gitlab pipeline:

* Upload a app file (e.g apk) to Pcloudy
* Book a device in Pcloudy for app testing
* Perform your Appium tests
* Download Pcloudy logs
* Release the Pcloudy device

### Demonstrating:
* .hatspcloudycli-upload from [templates/.gitlab-ci-pcloudy-test.yml](../templates#template-hatspcloudycli-upload)
* .hatspcloudycli-book-app from [templates/.gitlab-ci-pcloudy-test.yml](../templates#template-hatspcloudycli-book-app)
* .run-robot-test from [templates/.gitlab-ci-run-test.yml](../templates#template-run-robot-test)
* .hatspcloudycli-download-logs from [templates/.gitlab-ci-pcloudy-test.yml](../templates#template-hatspcloudycli-download-logs)
* .hatspcloudycli-release from [templates/.gitlab-ci-pcloudy-test.yml](../templates#template-hatspcloudycli-release)

### Sample-apps:
* [supporting-apps/pcloudy-resources](../supporting-apps/pcloudy-resources)

## Example: [Pcloudy-Test-Browser](Pcloudy-Test-Browser.yml)

### Target user:

This example shows how to do the following in a Gitlab pipeline:

* Book a device in Pcloudy to do browser testing
* Perform your Appium tests
* Download Pcloudy logs
* Release the Pcloudy device

### Demonstrating:
* .hatspcloudycli-book-browser from [templates/.gitlab-ci-pcloudy-test.yml](../templates#template-hatspcloudycli-book-browser)
* .run-robot-test from [templates/.gitlab-ci-run-test.yml](../templates#template-run-robot-test)
* .hatspcloudycli-download-logs from [templates/.gitlab-ci-pcloudy-test.yml](../templates#template-hatspcloudycli-download-logs)
* .hatspcloudycli-release from [templates/.gitlab-ci-pcloudy-test.yml](../templates#template-hatspcloudycli-release)

### Sample-apps:
* [supporting-apps/pcloudy-resources](../supporting-apps/pcloudy-resources)

## Example: [Readiness-Check-For-Docker-Service](Readiness-Check-For-Docker-Service.yml)

### Target user:

This example shows how to do the following in a GitLab pipeline:
* Setup Docker services to facilitate runtime testing from image published to a private registry, for e.g., SHIP's Nexus Repository.

### Demonstrating:
* .build-and-push-docker-image from [templates/.gitlab-ci-docker-build.yml](../templates#template-build-and-push-docker-image)
* .wait-for-docker-services from [templates/.gitlab-ci-check-app-readiness.yml](../templates#template-wait-for-docker-services)

### Sample-apps:
* [supporting-apps/simple-docker-app](../supporting-apps/simple-docker-app)

## Example: [Fod-Sast](Fod-Sast.yml)

### Target user:

This example shows how to do the following in a GitLab pipeline:

* Packaging JavaDocker source code using ScanCentral
* Packaging Maven Jdk 8 source code using ScanCentral
* Packaging Maven Jdk 11 source code using ScanCentral
* Uploading ScanCentral package using FoDUploader for SAST
* Generate Fortify Report based on the vulnerabilities detected

### Demonstrating:
* .fortify-sast-fod-with-report from [templates/.gitlab-ci-run-fod-scan.yml](../templates#template-fortify-sast-fod-with-report)

### Sample-apps:
* [supporting-apps/javadockerapp](../supporting-apps/javadockerapp)
* [WebGoat/v8.1.0] (https://github.com/WebGoat/WebGoat/tree/v8.1.0)
* [WebGoat/v8.0.0] (https://github.com/WebGoat/WebGoat/tree/v8.0.0)

## Example: [Fod-Dast](Fod-Dast.yml)

### Target user:

This example shows how to do the following in a GitLab pipeline:

* Run DAST scan on a dynamic web application

### Demonstrating:
* .fortify-dast from [templates/.gitlab-ci-run-fod-scan.yml](../templates#template-fortify-dast)

## Example: [Fod-Sast-MSBuild](Fod-Sast-MSBuild.yml)

### Target user:

This example shows how to do the following in a GitLab pipeline:

* Packaging .NET source code using ScanCentral
* Uploading ScanCentral package using FoDUploader for SAST
* Generate Fortify Report based on the vulnerabilities detected

### Demonstrating:
* .scancentral-package-msbuild from [templates/.gitlab-ci-run-fod-scan.yml](../templates#template-fortify-sast-fod-msbuild)
* .fortify-sast-msbuild-with-report from [templates/.gitlab-ci-run-fod-scan.yml](../templates#template-fortify-sast-fod-msbuild)

### Sample-apps:
* [supporting-apps/msbuild-sample-app](../supporting-apps/msbuild-sample-app)

## Example: [Fod-Sast-Generate-Report](Fod-Sast-Generate-Report.yml)

### Target user:

This example shows how to do the following in a GitLab pipeline:

* Generate SAST gitlab report for FOD application

### Demonstrating:
* .create-fod-sast-report from [templates/.gitlab-ci-create-fod-report.yml](../templates#template-create-fod-sast-report)

## Example: [Fod-Dast-Generate-Report](Fod-Dast-Generate-Report.yml)

### Target user:

This example shows how to do the following in a GitLab pipeline:

* Generate DAST gitlab report for FOD application

### Demonstrating:
* .create-fod-dast-report from [templates/.gitlab-ci-create-fod-report.yml](../templates#template-create-fod-dast-report)

## Example: [Maven-Artefact-Checksum-Verification](Maven-Artefact-Checksum-Verification.yml)

### Target user:

This example shows how to do the following in a GitLab pipeline:

* Build and publish maven artefact to a nexus repository.
* Perform a checksum validation between build and published application artefact.
* Sign application artefact and published application artefact signature.
* Pull the artefacts to be deployed by downloading them from Nexus Repository.

### Demonstrating:
* .publish-maven-artefact from [templates/.gitlab-ci-publish-to-nexus.yml](../templates#template-publish-maven-artefact)
* .verify-maven-artefact from [templates/.gitlab-checksum-verify](../templates#template-verify-maven-artefact)
* .sign-artifact from [templates/.gitlab-ci-blob-signing.yml](../templates#template-sign-artifact)
* .download-from-nexus-repo from [templates/.gitlab-ci-download-from-nexus-repo.yml](../templates#template-download-from-nexus-repo)

### Sample-apps:
* [supporting-apps/maven-simple-app](../supporting-apps/maven-simple-app)

## Example: [Postman-Test-And-Report](Postman-Test-And-Report.yml)

This example shows how to do following in a Gitlab pipeline:

* Run Postman api test and generate test reports (.html and .xml) from defined test script
* Passing API URL prefix as a global variable (e.g. api_url) to avoid hard-coding it in the test scripts

### Demonstrating:
* .run-postman-api-test from [templates/.gitlab-ci-postman.yml](../templates#template-run-postman-api-test)

### Sample-apps:
* [supporting-apps/postman-api-testcollection](../supporting-apps/postman-api-testcollection/)

## Example: [GitLab-Release-Management](GitLab-Release-Management.yml)

### Target user:

This example shows how to do the following in a Gitlab pipeline:

* Prepare a release - 
  1. Update version in README.md.
  2. Generate a changelog.
  3. Create an MR to merge changelog and readme changes.
* Approve a release, which will do - 
  1. Merge release MR from .release-prep.
  2. Tag commit in branch with version provided.
  3. Create a release in project's Deployment.
* Cleanup a release if it is not approved or lapsed.

### Demonstrating:
* .release-prep from [templates/.gitlab-ci-release-management](../templates#template-release-prep)
* .approve-release from [templates/.gitlab-ci-release-management](../templates#template-approve-release)
* .release-prep-revert from [templates/.gitlab-ci-release-management](../templates#template-release-prep-revert)
