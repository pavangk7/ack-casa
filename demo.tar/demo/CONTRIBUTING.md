## Getting started

To facilitate collaboration, please [**create an issue **](https://sgts.gitlab-dedicated.com/WOG/GVT/ship/ship-hats-templates/-/issues) first before implementation. Refer to: https://docs.gitlab.com/ee/development/cicd/templates.html for best practices in Development guide for CICD templates creation. For main branch commits, do make sure that you have a merge request approved by a maintainer.

### Process to contribute :
1. Create an issue for the usecase that you are implementing for. Check in issue list that its not currently worked on by others if it is not a fix.
2. Create a branch with the issue id for the feature based off the LATEST main. `git pull origin main`
3. Create a yaml file named after the use case you are implementing for, like `Nexus-Pull-And-Publish-MVN.yml` in gitlab-ci folder. Create a folder named after the sample application required for the use case, like `maven-simple-app` in the `supporting-apps` folder. This will contain a working sample application example showcasing your template/s.
4. Organise the modular/reusable template jobs from your use case in `templates` folder.
5. Please update README.md in gitlab-ci folder for your usecase with the instructions to run it following the format:
    ```md
    ## Example: [Name-of-Example](Name-of-Example.yml)
    
    ### Target user:
    
    Describe what this example showcases:
    * Feature 1
    
    ### Demonstrating:
    * .job-name from [templates/.gitlab-ci-file-name.yml](../templates#template-job-name)
    
    ### Sample-apps:
    <!-- Include Sample application/s that are used in this example if applicable. -->
    * [supporting-apps/sample-app-name](../supporting-apps/sample-app-name)
    ```

    Do add your use case to the "Table of Contents" in this README.md. Check out an [Example](gitlab-ci/README.md) here.

6. Please include in your template job usage in templates/README.md following the format:
    ```md
    <!-- Include "## File" if it is a new file -->
    ## File: [.gitlab-ci-file-name.yml](.gitlab-ci-file-name.yml)
    
    ### Template: .job-name
    
    ### Target user:
    
    Describe what this template showcases.
    
    ### Add on implementation should go in:
    
    <!-- Possible values are "before_script", "script" and "after_script" -->
    * script
    
    ### See example/s :
    
    * Name-of-Example: [Sample usage code](../gitlab-ci/Name-of-Example.yml) and [Documentation](../gitlab-ci#example-name-of-example)
    <!-- Include Sample application/s that are used in this example if applicable. -->
    * [supporting-apps/sample-app-name](../supporting-apps/sample-app-name)
    
    ### Variable/s to set:
    <!-- Assign "NA" if not applicable -->
    |Key             |Required |Description | 
    |----------------|------------|------------|
    |VARIABLE_NAME | <!-- Possible values are "Y" or "N" --> Y | Description of VARIABLE_NAME; can include example and default value. |
    
    ### CICD Settings/Variables to set:
    <!-- Assign "NA" if not applicable -->
    |Key             |Required |Description|
    |----------------|-----------|-----------|
    |SENSITIVE_VARIABLE_NAME | <!-- Possible values are "Y" or "N" --> Y | Description of SENSITIVE_VARIABLE_NAME; can include example and default value. |
    
    ### Known issue/s:
    <!-- Assign "NA" if not applicable -->
    * issue 1
    
    ### Reference/s:
    <!-- Assign "NA" if not applicable -->
    NA
    ```

    You may include 'Disclaimer', 'Prerequisites', 'Dependencies:' and/or 'Usage Example/s:' if required. Do add your template job to the "Table of Contents" in this README.md. Check out [Examples](templates/README.md) here.

7. Add a triggering job in the main pipeline [here](./.gitlab-ci.yml) for testing.
* The `$WORKING_DIR` variable is to specify the child's pipeline working directory since triggering from the main pipeline will set the CI home to `SHIP-HATS\ Templates/` instead of the child's directory.
* If the example require sensitive variables, pls do not include as this project's CICD variables. You could input the sensitive variables under manual trigger (Remember to escape $ sign with $ sign). In `if-run-example`, you may use `$ship_run_job` to choose the job to test.
* Optionally, it is a good practice to run the example so long as the template changes.
For eg:

    ```yaml
    gitlab-ci-run-example:
      stage: build
      only:
        changes:
          - templates/.gitlab-ci-run-example.yml
    ```
    
8. If this implementation impacts users (e.g. a new template, template updated with new variables etc), please include a changelog entry by git-committing with a trailer message that conforms to this [format](https://docs.gitlab.com/ee/development/changelog.html#overview): `Changelog: <fixed/added/removed/changed/security/deprecated/performance>`. This changelog entry will be automatically added to [CHANGELOG.md](./CHANGELOG.md) during each release so please make sure to write a [good changelog entry](https://docs.gitlab.com/ee/development/changelog.html#writing-good-changelog-entries). 

   Example of how to run git commit with trailer : git commit -S -m "Added new template to do <X>" --trailer "Changelog: added".

   Alternatively, one may include the trailer in the merge request commit message during the merge approval.

   Sample changes that potentially impact users:
    * Breaking changes
    * Deprecations / Removed Templates
    * New Templates

9. Raise merge request for approval.



### Repo Directory Structure Example:
``` bash
/
|----- This CONTRIBUTING.md
|----- README.md
|----- templates/ # contains templates to include
|----- .gitlab-ci.yml # main pipeline
            |----- .gitlab-ci-publish-to-nexus.yml
            |----- README.md
            |----- vars # contains variables to include
               |-----.gitlab-sonatype-variables.yml
|----- gitlab-ci/  # contains examples to use the templates
            |----- Nexus-Pull-And-Publish-MVN.yml
            |----- README.md
|----- supporting-apps/  # contains sample application to use the templates
            |----- maven-simple-app/
                        |----- / (dependencies for this usecase cicd) /
```

### Notes :
* Try not to include repositories that require special access.
* Try to structure modular / reusable usecases.
* Try not to put real passwords in examples.
* Try to provide a passing pipeline in MR.
* Some very good tips on how you may perform development outside before raising merge request : https://docs.gitlab.com/ee/user/project/repository/forking_workflow.html
* A good template is one that users can refer to README.md and treat the implementation like a blackbox.

# Contributors:
* SHIP
* CTMO
* Codex
* Gitlab PS