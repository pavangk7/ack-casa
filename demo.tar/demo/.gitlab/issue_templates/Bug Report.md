<!--
Predefined issue for reporting bugs in SHIP-HATS Templates. Adapted from https://gitlab.com/gitlab-org/gitlab/-/raw/master/.gitlab/issue_templates/Bug.md

While keeping to the structured form of documentation, you may add sections if absolutely necessary.
-->

# Bug Report
<!-- Title should appropriately highlight the bug needed to be fixed -->

## Affected Templates
<!-- List the template/s affected by the bug. NA if not applicable. -->

- [template 1](https://template1)
- [template 2](https://template2)

## Bug Encountered
<!-- Describe what actually happened. -->

## Steps to reproduce
<!-- Describe how one can reproduce the issue - this is very important. Please use an ordered list. -->

## What should be the correct behavior?
<!-- Describe what you should see instead. -->

## Relevant logs and/or screenshots
<!-- Paste any relevant logs - please use code blocks (```) to format console output, logs, and code as it's tough to read otherwise. -->

## Possible fixes
<!-- Please feel free to suggest a fix. It would also be very helpful if you could link to the line of code that might be responsible for the problem. -->
