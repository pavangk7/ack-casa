<!--
Predefined issue for implementing new template in SHIP-HATS Templates.

Before contributing, it is recommended to first go through [Contributing Guide](https://sgts.gitlab-dedicated.com/WOG/GVT/ship/ship-hats-templates/-/blob/main/CONTRIBUTING.md).

While keeping to the structured form of documentation, you may add sections if absolutely necessary.
-->

# New Template
<!-- Title should appropriately highlight the functionalities of the template -->

## Objective
<!--
Please explain how this template could be useful to the other users, ideally it should follow the "write once, used anywhere" principle. It may also be good to include the intention/rationale for creating this template as the reader might not know the background.
-->

## Use Cases
<!-- Please describe what this template can do. -->

## Variable/s to set
<!-- 
|Key             |Required |Description | 
|----------------|------------|------------|
|variable1_name | Y/N | Description for variable 1.|
|variable2_name | Y/N | Description for variable 2.|

NA if not applicable
-->

## CICD Settings/Variables to set
<!-- 
|Key             |Required |Description | 
|----------------|------------|------------|
|variable1_name | Y/N | Description for variable 1.|
|variable2_name | Y/N | Description for variable 2.|

NA if not applicable
-->

## Output/Artifacts
<!-- List the output produced by the template. Nil if nothing is produced. -->

- Scan report
- Artefact eg. archive of files and folders or XML files
- A pushed image in some docker registry

## Dependencies
<!-- List dependencies if any. NA if not applicable. -->

## References
<!-- List references if any. NA if not applicable. -->

## Checklist
<!-- Add/delete/modify items as necessary. -->

- [ ] Implement template in [templates](templates)
- [ ] Implement sample usage in [gitlab-ci](gitlab-ci)
- [ ] Update [.gitlab-ci.yml](.gitlab-ci.yml) for sample usage to work
- [ ] Add documentation for template in [templates README.md](templates/README.md)
- [ ] Add documentation for sample usage in [gitlab-ci README.md](gitlab-ci/README.md)