Before creating an issue, please read through our contributing guide for helpful information such as contributing workflow, best practices, directory structure and etc:

* [Contributing Guide](CONTRIBUTING.md)

We would also recommend to check through the issue list to ensure that what you have in mind is not currently worked on by others.

It is also advisable to use one of the issue templates provided and include as much information as possible. Currently, we have issue templates catering for:

* New Template
* Bug Report

Should your issue not fall under the above categories, please start with a blank issue and try to include as much information as possible.