## 1.0.4 (2022-12-12)

### removed (2 changes)


- [1. Removed docker checksum](wog/gvt/ship/ship-hats-templates@5100c04e818cc20d259b38a150e1a1c59e7254b5) by @chua_peiling ([merge request](wog/gvt/ship/ship-hats-templates!219))

- [Remove twistlock template](wog/gvt/ship/ship-hats-templates@6d890acc9ea8c5b288ed480e1841d5695a298585) by @lee_jie_han ([merge request](wog/gvt/ship/ship-hats-templates!212))

### fixed (2 changes)


- [1. Enhanced docker auth to allow docker user and pass.](wog/gvt/ship/ship-hats-templates@d6e69a6f422f71b98ec3977dfdf9a6f249f405eb) by @chua_peiling ([merge request](wog/gvt/ship/ship-hats-templates!217))

- [Updated fod scan paramters](wog/gvt/ship/ship-hats-templates@0c8176eb1513c7e765e045149e93a54b7319e159) by @lee_jie_han ([merge request](wog/gvt/ship/ship-hats-templates!191))

### changed (8 changes)


- [update according to suggestions](wog/gvt/ship/ship-hats-templates@d618e831a94cbb04487f27e07af114edda145f16) by @goh_chun_teck ([merge request](wog/gvt/ship/ship-hats-templates!215))

- [remove reliance on docker in docker](wog/gvt/ship/ship-hats-templates@91935bfdf90e2b9fcda218de673966a44b3cd5dc) by @goh_chun_teck ([merge request](wog/gvt/ship/ship-hats-templates!215))

- [Changed variable for optional arguments for sonarqube-scan-dotnet-framework](wog/gvt/ship/ship-hats-templates@47c689d59d01073fcd4f1515964239bb709afe6b) by @ramanathan_anu ([merge request](wog/gvt/ship/ship-hats-templates!216))

- [Update check on docker_auth_config var with .check-docker-auth-config.sh](wog/gvt/ship/ship-hats-templates@eaea89e1f38dda6594aecdcb59094196e3a9fca9) by @tay_geok_rong ([merge request](wog/gvt/ship/ship-hats-templates!209))

- [Add in checks on docker config.json for sign-container and verify-container templates](wog/gvt/ship/ship-hats-templates@2332f214161e8d0fa5838444ee2a8969ac6c51f3) by @tay_geok_rong ([merge request](wog/gvt/ship/ship-hats-templates!205))

- [Remove IMAGE_NAME as required variable in docker delete template](wog/gvt/ship/ship-hats-templates@01ef9ecfd9ac18797062f8705462864abc1cfe2f) by @tay_geok_rong ([merge request](wog/gvt/ship/ship-hats-templates!207))

- [Shift before_script into script for .sign-container and .verify-container templates](wog/gvt/ship/ship-hats-templates@0722d6497ab6e61e73efec5b23f121763ed559da) by @tay_geok_rong ([merge request](wog/gvt/ship/ship-hats-templates!204))

- [Update cosign templates to allow pass in of cosign_key and cosign_pub](wog/gvt/ship/ship-hats-templates@7c3492dafb592dd609e73c72a3ea71ff95d50e63) by @tay_geok_rong ([merge request](wog/gvt/ship/ship-hats-templates!197))

## 1.0.3 (2022-10-25)

### changed (3 changes)


- [Edit sonarqube-scan-dotnet to be consistent with sonarqube-scan-dotnet-framework template](wog/gvt/ship/ship-hats-templates@e723a81f53cd00900ab98ee527e29a1158b18ec6) by @ramanathan_anu ([merge request](wog/gvt/ship/ship-hats-templates!196))

- [Move template from .gitlab-ci-kubectl-aws.yml to .gitlab-ci-aws.yml](wog/gvt/ship/ship-hats-templates@e61089e89e11f821b29e512d4bcde1158a215cea) by @tay_geok_rong ([merge request](wog/gvt/ship/ship-hats-templates!190))

- [update pcloudy image tag](wog/gvt/ship/ship-hats-templates@2914347bd25166d2fca270f94d86a30fa04e643a) by @goh_chun_teck ([merge request](wog/gvt/ship/ship-hats-templates!188))

### added (1 change)


- [Add invoke-ecr-token-retrieval](wog/gvt/ship/ship-hats-templates@24caf0267a559c532b0b01cf5cc2b576874d16c6) by @tay_geok_rong ([merge request](wog/gvt/ship/ship-hats-templates!190))

## 1.0.2 (2022-09-22)

### fixed (1 change)


- [Update variable checks for .fortify-sast-msbuild-with-report](wog/gvt/ship/ship-hats-templates@a795b1be15d1ec45c328cf5ef830339b7cd89401) by @tay_geok_rong ([merge request](wog/gvt/ship/ship-hats-templates!183))

### added (1 change)


- [Added sonarqube-scan-dotnet-framework and sonarqube-output-report](wog/gvt/ship/ship-hats-templates@ef3fd2d8078772fd0a9c32ed577709d770bee8d6) by @lee_jie_han ([merge request](wog/gvt/ship/ship-hats-templates!159))

## 1.0.1 (2022-09-19)

### fixed (2 changes)


- [Update Prod Windows runner tags for .scancentral-package-msbuild template](wog/gvt/ship/ship-hats-templates@72a263ef9aae3cca4a663c8f226891a7b6746dac) by @tay_geok_rong ([merge request](wog/gvt/ship/ship-hats-templates!177))

- [Update Prod Windows runner tags](wog/gvt/ship/ship-hats-templates@cee01238080ddbeacdf09cddd83d0d850fd85ce1) by @tay_geok_rong ([merge request](wog/gvt/ship/ship-hats-templates!176))

### added (1 change)


- [Added purple hats](wog/gvt/ship/ship-hats-templates@baa5a68fc1b7e7a78442cc75c5f4157973afa5c3) by @lee_jie_han ([merge request](wog/gvt/ship/ship-hats-templates!180))

### changed (1 change)


- [Filenames .gitlab-ci-run-fod-sast.yml, .gitlab-ci-run-fod-dast.yml,...](wog/gvt/ship/ship-hats-templates@5ec403a3772aa79db56e489b137ee6b4519c5b81) by @tay_geok_rong ([merge request](wog/gvt/ship/ship-hats-templates!175))
