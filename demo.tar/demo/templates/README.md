# Table of Contents:
1. [Docker pull from Nexus Repository](#file-gitlab-ci-nexus-docker-pullyml)
    - [Proxy](#template-pull-docker-image-fr-proxy-nexus-repo)
    - [Hosted](#template-pull-docker-image-fr-hosted-nexus-repo)
2. [Docker push to Private Registry](#file-gitlab-ci-docker-pushyml) 
3. [Docker copy image from one remote registry to another registry](#file-gitlab-ci-docker-copyyml)  
4. [Docker build](#file-gitlab-ci-docker-buildyml)
    - [Build and push](#template-build-and-push-docker-image)
    - [Build and export as artifact](#template-build-docker-image)
5. [Docker delete images](#file-gitlab-ci-docker-deleteyml)
    - [Delete image from GitLab Container Registry](#template-delete-gitlab-cr-image)
6. [Publish an artefact to Nexus Repo](#file-gitlab-ci-publish-to-nexusyml)
    - [Publish an artefact to a hosted Maven repository in Nexus Repo](#template-publish-maven-artefact)
    - [Publish an artefact to a hosted NPM repository in Nexus Repo](#template-publish-nodejs-artefact)
    - [Publish an artefact to a hosted NuGet repository in Nexus Repo using NuGet CLI](#template-publish-nuget-artefact-using-nuget-cli)
    - [Publish an artefact to a hosted NuGet repository in Nexus Repo using dotNet CLI](#template-publish-nuget-artefact-using-dotnet-cli)
7. [Check application readiness](#file-gitlab-ci-check-app-readinessyml)
    - [Wait for app and assert text](#template-wait-for-app-and-assert-text)
    - [Wait for docker services](#template-wait-for-docker-services)
8. [Invoke Azure CLI commands](#file-gitlab-ci-azureyml)
9. [AWS](#file-gitlab-ci-awsyml)
   - [Invoke AWS CLI commands](#template-invoke-awscli-commands-with-assumerole)
   - [Invoke AWS Secret Retrieval](#template-invoke-awssecretretrieval)
   - [Invoke Kubectl AWS EKS commands](#template-invoke-kubectlupdateconfig)
   - [Invoke AWS ECR token retrieval](#template-invoke-ecr-token-retrieval)
10. [Nexus IQ Scan](#file-gitlab-ci-nexus-iq-scanyml)
11. [Configure to use Nexus Repo](#file-gitlab-ci-nexus-configureyml)
    - [NPM](#template-configure-npm-for-nexus)
    - [NuGet using NuGet CLI - Publish](#template-configure-publish-nuget-for-nexus-using-nuget-cli)
    - [NuGet using dotNet CLI - Publish](#template-configure-publish-nuget-for-nexus-using-dotnet-cli)
12. [Robot Framework Test](#file-gitlab-ci-run-testyml)
13. [Robot Framework Create Report](#file-gitlab-ci-create-reportyml)
14. [Run depcheck for NPM projects](#file-gitlab-ci-nodejs-commonyml)
15. [Aquasec Trivy Scan](#file-gitlab-ci-aquasec-trivy-scanyml)
16. [Cosign Signing and Verification](#file-gitlab-ci-container-signingyml)
    - [Sign Container](#template-sign-container)
    - [Verify Container](#template-verify-container)
17. [Blob Signing](#file-gitlab-ci-blob-signingyml)
    - [Sign Artifact](#template-sign-artifact)
    - [Verify Artifact](#template-verify-artifact)
18. [Pcloudy Test](#file-gitlab-ci-pcloudy-testyml)
    - [Upload application](#template-hatspcloudycli-upload)
    - [Book device for application file testing](#template-hatspcloudycli-book-app)
    - [Book device for browser testing](#template-hatspcloudycli-book-browser)
    - [Download logs](#template-hatspcloudycli-download-logs)
    - [Release a booked device](#template-hatspcloudycli-release)
19. [FOD Scan](#file-gitlab-ci-run-fod-scanyml)
    - [SAST](#template-fortify-sast-fod-with-report)
    - [DAST](#template-fortify-dast)
    - [Package .NET source code using ScanCentral for FOD SAST processing](#template-scancentral-package-msbuild)
    - [SAST-MSBuild](#template-fortify-sast-msbuild-with-report)
20. [FOD Report](#file-gitlab-ci-create-fod-reportyml)
    - [SAST](#template-create-fod-sast-report)
    - [DAST](#template-create-fod-dast-report)
21. [Sonarqube Scan](#file-gitlab-ci-sonarqubeyml)
    - [Sonarqube Scan](#template-sonarqube-scan)
    - [Sonarqube Scan for Maven](#template-sonarqube-scan-maven)
    - [Sonarqube Scan for .NET Core](#template-sonarqube-scan-dotnet)
    - [Sonarqube Scan for .NET Framework](#template-sonarqube-scan-dotnet-framework)
    - [Sonarqube output report](#template-sonarqube-output-report)
22. [Checksum Verification](#file-gitlab-ci-checksum-verifyyml)
    - [Verify Maven Artefact](#template-verify-maven-artefact)
    - [Verify Other Artefact](#template-verify-artefact-checksum)
23. [Postman API Test](#file-gitlab-ci-postmanyml)
24. [GitLab API](#file-gitlab-ci-gitlab-apiyml)
    - [Generate Changelog](#template-generate-changelog)
    - [Create Merge Request](#template-create-mr)
    - [Merge Merge Request](#template-merge-mr)
    - [Update version in file as commit](#template-update-version-in-file-as-commit)
    - [Create Release API](#template-create-release-api)
    - [Release Prep Revert](#template-release-prep-revert)
25. [GitLab Release Management](#file-gitlab-ci-release-managementyml)
    - [Check release version syntax](#template-check-release-version-syntax)
    - [Create Branch](#template-create-branch)
    - [Create Tag](#template-create-tag)
    - [Create Release](#template-create-release)
    - [Release Prep](#template-release-prep)
    - [Approve Release](#template-approve-release)
26. [Download from Nexus Repo](#file-gitlab-ci-download-from-nexus-repoyml)
27. Shared contents:
    - [Base64 encoding](#base64-encoding)



## File: [.gitlab-ci-nexus-docker-pull.yml](.gitlab-ci-nexus-docker-pull.yml)

### Template: .pull-docker-image-fr-proxy-nexus-repo

### Target user:

This template allows users to pull a docker image as ./output.tar through SHIP Nexus Repository docker-proxy in the "before_script" key for a job.

### Add on implementation should go in:

* script
* after_script

### See example/s:

* Nexus-Docker-Pull-And-Scan: [Sample usage code](../gitlab-ci/Nexus-Docker-Pull-And-Scan.yml) and [Documentation](../gitlab-ci#example-nexus-docker-pull-and-scan)

### Variable/s to set:
|Key             |Required |Description |
|----------------|------------|------------|
|NEXUSREPO_DOCKER_IMAGE | Y | "maven:latest"|
|OUTPUT_IMAGE_TAR | N | Defaults to "output.tar" if unsupplied.|

### CICD Settings/Variables to set:
NA

### Known issue/s:
NA

### Reference/s:
* [crane pull](https://github.com/google/go-containerregistry/blob/main/cmd/crane/doc/crane_pull.md)

### Template: .pull-docker-image-fr-hosted-nexus-repo

### Target user:

This template allows users to pull a docker image as  ./output.tar through SHIP Nexus Repository hosted docker registry in the "before_script" key for a job.

### Add on implementation should go in:

* script
* after_script

### See example/s:

* Nexus-Docker-Pull-And-Scan: [Sample usage code](../gitlab-ci/Nexus-Docker-Pull-And-Scan.yml) and [Documentation](../gitlab-ci#example-nexus-docker-pull-and-scan)

### Variable/s to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|NEXUSREPO_DOCKER_IMAGE | Y | "ship-test/docker/getting-started:latest"|
|OUTPUT_IMAGE_TAR | N | Defaults to "output.tar" if unsupplied.|

### CICD Settings/Variables to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|DOCKER_AUTH_CONFIG | N | {"auths": { "$NEXUSREPO_DOCKER_HOSTED_HOSTNAME": { "auth": "Provide base64 encoded nexus_username:nexus_password here, use escape keys if necessary. See [how](#base64-encoding) to do it." } } }  . This template checks for docker config.json file which is created upon docker login or passed in as an artifact from previous job. In such cases, this variable would not be required.|
|DOCKER_USER | N | Nexus Repo username to use as an alternative to DOCKER_AUTH_CONFIG. |
|DOCKER_PASSWORD | N | Nexus Repo token to use as an alternative to DOCKER_AUTH_CONFIG. |

### Known issue/s:
NA

### Reference/s:
* [crane pull](https://github.com/google/go-containerregistry/blob/main/cmd/crane/doc/crane_pull.md)

## File: [.gitlab-ci-docker-build.yml](.gitlab-ci-docker-build.yml)

### Template: .build-and-push-docker-image

### Target user:

This template allows users to do build and push docker image to private registry in one single action which is defined in the "script" key.

### Add on implementation should go in:

* before_script
* after_script

### See example/s:

* Container-Signing: [Sample usage code](../gitlab-ci/Container-Signing.yml) and [Documentation](../gitlab-ci#example-container-signing)
* [supporting-apps/simple-docker-image](../supporting-apps/simple-docker-image)
* Readiness-Check-For-Docker-Service: [Sample usage code](../gitlab-ci/Readiness-Check-For-Docker-Service.yml) and [Documentation](../gitlab-ci#example-readiness-check-for-docker-service)
* [supporting-apps/simple-docker-app](../supporting-apps/simple-docker-app)

### Variable/s to set:
|Name            | Required | Description|
|----------------|-----------|-----------|
|DOCKER_TARGET_REGISTRY | Y | "$NEXUSREPO_DOCKER_HOSTED_HOSTNAME/ship-test" for SHIP's Nexus Repo. Remember to include the Content Selector as shown in the example ("/ship-test"); "$CI_REGISTRY" for GitLab Container Registry; For AWS ECR, "(Your AWS acct number).dkr.ecr.ap-southeast-1.amazonaws.com". |
|DOCKER_TARGET_IMAGE | Y | "kaniko-debug-image:latest" |
|DOCKERFILE_PATH | N | Defaults to "./" if unsupplied. |
|DOCKERFILE_NAME | N | Defaults to "Dockerfile" if unsupplied. |
|DIGESTFILE_NAME | N | Defaults to "$CI_PROJECT_DIR/digest" if unsupplied.  |
|OPTS | N | Defaults to "" if unsupplied. Optional flags for Kaniko cmd. |

### CICD Settings/Variables to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|DOCKER_AUTH_CONFIG | N | {"auths": { "$DOCKER_TARGET_REGISTRY": { "auth": "Provide base64 encoded username and password here, use escape keys if necessary. See [how](#base64-encoding) to do it." } } } . This template checks for docker config.json file which is created upon docker login or passed in as an artifact from previous job. In such cases, this variable would not be required.|
|DOCKER_USER | N | Docker username to use as an alternative to DOCKER_AUTH_CONFIG. For AWS ECR, it can be "AWS". |
|DOCKER_PASSWORD | N | Docker password to use as an alternative to DOCKER_AUTH_CONFIG. For AWS ECR, it can be ECR token generated by [.invoke-ecr-token-retrieval](#template-invoke-ecr-token-retrieval). |

### Known issue/s:
NA

### Reference/s:
* [Underlying Kaniko docs](https://github.com/GoogleContainerTools/kaniko/blob/main/README.md#additional-flags)

### Template: .build-docker-image

### Target user:

This template allows users to build a docker image and exports it as ./output.tar, which is defined in the "script" key. 

### Add on implementation should go in:

* before_script
* after_script

### See example/s:

* Private-Registry-Docker-Push: [Sample usage code](../gitlab-ci/Private-Registry-Docker-Push.yml) and [Documentation](../gitlab-ci#example-private-registry-docker-push)
* [supporting-apps/simple-docker-image](../supporting-apps/simple-docker-image)
* Aquasec-Trivy-Scan-File: [Sample usage code](../gitlab-ci/Aquasec-Trivy-Scan-File.yml) and [Documentation](../gitlab-ci#example-aquasec-trivy-scan-file)
* [supporting-apps/aquasec-trivy-scan](../supporting-apps/aquasec-trivy-scan)

### Variable/s to set:
|Name            | Required | Description|
|----------------|-----------|-----------|
|DOCKERFILE_PATH | N | Defaults to "./" if unsupplied. |
|DOCKERFILE_NAME | N | Defaults to "Dockerfile" if unsupplied. |
|OPTS | N | Defaults to "" if unsupplied. Optional flags for Kaniko cmd. |
|OUTPUT_IMAGE_TAR | N | Defaults to "output.tar" if unsupplied.|

### CICD Settings/Variables to set:
NA

### Known issue/s:
NA

### Reference/s:
* [Underlying Kaniko docs](https://github.com/GoogleContainerTools/kaniko/blob/main/README.md#additional-flags)

## File: [.gitlab-ci-docker-push.yml](.gitlab-ci-docker-push.yml)

### Template: .push-docker-image-to-private-registry

### Target user:

This template allows users to push docker image defined as a tar file to private registry, which is defined in the "after_script" key. It takes care of registry authentication in the "before_script" key.

### Add on implementation should go in:

* script

### See example/s:

* Private-Registry-Docker-Push: [Sample usage code](../gitlab-ci/Private-Registry-Docker-Push.yml) and [Documentation](../gitlab-ci#example-private-registry-docker-push)
* [supporting-apps/simple-docker-image](../supporting-apps/simple-docker-image)

### Variable/s to set:
|Name            | Required | Description|
|----------------|-----------|-----------|
|DOCKER_TARGET_REGISTRY | Y | "$NEXUSREPO_DOCKER_HOSTED_HOSTNAME/ship-test" for SHIP's Nexus Repo. Remember to include the Content Selector as shown in the example ("/ship-test"); "$CI_REGISTRY" for GitLab Container Registry; For AWS ECR, "(Your AWS acct number).dkr.ecr.ap-southeast-1.amazonaws.com". |
|DOCKER_TARGET_IMAGE | Y | "kaniko-debug-image:latest" |
|TAR_PATH | Y | Source docker image as tar file. |

### CICD Settings/Variables to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|DOCKER_AUTH_CONFIG| N | {"auths": { "$DOCKER_TARGET_REGISTRY": { "auth": "Provide base64 encoded username and password here, use escape keys if necessary. See [how](#base64-encoding) to do it." } } }. To authenticate with an OCI registry. This template checks for docker config.json file which is created upon docker login or passed in as an artifact from previous job. In such cases, this variable would not be required. |
|DOCKER_USER | N | Docker username to use as an alternative to DOCKER_AUTH_CONFIG. For AWS ECR, it can be "AWS". |
|DOCKER_PASSWORD | N | Docker password to use as an alternative to DOCKER_AUTH_CONFIG. For AWS ECR, it can be ECR token generated by [.invoke-ecr-token-retrieval](#template-invoke-ecr-token-retrieval). |

### Known issue/s:
* Should the after_script fails, job status will be 'passed'. This is a design bug that has been raised to GitLab for workarounds.

### Reference/s:
* [Underlying Crane docs](https://github.com/google/go-containerregistry/blob/main/cmd/crane/doc/crane.md)

## File: [.gitlab-ci-docker-copy.yml](.gitlab-ci-docker-copy.yml)

### Template: .copy-docker-image-from-one-remote-registry-to-another

### Target user:

This template allows users to copy a docker image from one remote registry to another remote registry, which is defined in the "script" key.

### Add on implementation should go in:

* before_script
* after_script

### See example/s:

* Container-Signing: [Sample usage code](../gitlab-ci/Container-Signing.yml) and [Documentation](../gitlab-ci#example-container-signing)
* [supporting-apps/simple-docker-image](../supporting-apps/simple-docker-image)

### Variable/s to set:
|Name            | Required | Description|
|----------------|-----------|-----------|
|SRC_IMAGE | Y | "$NEXUSREPO_DOCKER_HOSTED_HOSTNAME/ship-test/test:latest" for SHIP's Nexus Repo. Remember to include the Content Selector as shown in the example ("/ship-test"); "$CI_REGISTRY:latest" for GitLab Container Registry; For AWS ECR, "(Your AWS acct number).dkr.ecr.ap-southeast-1.amazonaws.com/test:latest". |
|DEST_IMAGE | Y | "$NEXUSREPO_DOCKER_HOSTED_HOSTNAME/ship-test/test:latest" for SHIP's Nexus Repo. Remember to include the Content Selector as shown in the example ("/ship-test"); "$CI_REGISTRY:latest" for GitLab Container Registry; For AWS ECR, "(Your AWS acct number).dkr.ecr.ap-southeast-1.amazonaws.com/test:latest". |
|OPTS | N | Skopeo command options and arguments. Refer to Reference/s.|

### CICD Settings/Variables to set:
NA

### Known issue/s:
NA

### Reference/s:
* [Underlying Skopeo docs](https://github.com/containers/skopeo#commands)

## File: [.gitlab-ci-docker-delete.yml](.gitlab-ci-docker-delete.yml)

### Template: .delete-gitlab-cr-image

### Target user:

This template allows users to delete image together with its cosign signature (if exists) from GitLab Container Registry, which is defined in the "script" key.

### Add on implementation should go in:

* before_script
* after_script

### See example/s:

* Container-Signing: [Sample usage code](../gitlab-ci/Container-Signing.yml) and [Documentation](../gitlab-ci#example-container-signing)
* [supporting-apps/simple-docker-image](../supporting-apps/simple-docker-image)

### Variable/s to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|IMAGE_VERSION| Y | Target image version for deletion. |
|IMAGE_NAME| N | Target image name for deletion. |

### CICD Settings/Variables to set
|Key             |Required |Description|
|----------------|-----------|-----------|
|API_TOKEN| Y | Gitlab API access token with minimally read and write api permissions to project.|

### Known issue/s:
NA

### Reference/s:
* [Create a project access token](https://docs.gitlab.com/ee/user/project/settings/project_access_tokens.html#create-a-project-access-token)
* [Delete Images using the API](https://docs.gitlab.com/ee/user/packages/container_registry/#delete-images-using-the-api)

## File: [.gitlab-ci-publish-to-nexus.yml](.gitlab-ci-publish-to-nexus.yml)

### Template: .publish-maven-artefact

### Target user:

This template allows users to publish maven artefacts to SHIP's Nexus Repo as the main job script.

### Add on implementation should go in:

* before_script
* after_script

### See example/s:

* Nexus-Pull-And-Publish-MVN: [Sample usage code](../gitlab-ci/Nexus-Pull-And-Publish-MVN.yml) and [Documentation](../gitlab-ci#example-nexus-pull-and-publish-mvn)
* Maven-Artefact-Checksum-Verification: [Sample usage code](../gitlab-ci/Maven-Artefact-Checksum-Verification.yml) and [Documentation](../gitlab-ci#example-maven-artefact-checksum-verification)
* [supporting-apps/maven-simple-app](../supporting-apps/maven-simple-app)

### Variable/s to set:
|Key             |Required |Description |
|----------------|-----------|-----------|
|MAVEN_SETTINGS_SERVER_ID | Y | Server id in settings.yml.|
|NEXUSREPO_REPO_ID | Y | Nexus repo name that your team uses.|
|NEXUSREPO_REPO_GROUP_ID | Y | Directory structure storing your artefact specified like Java's package name rules.|
|MVN_SETTINGS_FILE | Y | Authentication details to access Nexus Repo. Check out an [example](../supporting-apps/maven-simple-app/settings.xml).|
|ARTEFACT | Y | Path to artefact.|
|ARTEFACT_ID | Y | Artefact id.|
|ARTEFACT_VERSION | Y | Artefact version.|
|ARTEFACT_PACKAGE | Y | Artefact package. Common values - jar/war. |

### CICD Settings/Variables to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|NEXUS_REPO_USERNAME | Y | Service account username required in settings.yml to authenticate with Nexus Repo.|
|NEXUS_REPO_PASSWORD | Y | Service account password required in settings.yml to authenticate with Nexus Repo.|

### Known issue/s:
NA

### Reference/s:
NA

### Template: .publish-nodejs-artefact

### Target user:

This template allows users to publish nodejs artefacts to SHIP's Nexus Repo. This template leverages on [.configure-npm-for-nexus](#template-configure-npm-for-nexus) to use SHIP's Nexus Repo as registry in the "before_script" key and publishes the artefact in the "script" key for a job.

### Add on implementation should go in:

* after_script

### See example/s:

* Nexus-Pull-Scan-And-Publish-NPM: [Sample usage code](../gitlab-ci/Nexus-Pull-Scan-And-Publish-NPM.yml) and [Documentation](../gitlab-ci#example-nexus-pull-scan-and-publish-npm)
* [supporting-apps/nodejs-simple-library](../supporting-apps/nodejs-simple-library)

### Variable/s to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|NEXUSREPO_REPO_ID  | Y | Nexus repo name (type: hosted, format: npm) that your team uses.|
|NODE_VERSION | N | Node version to use; this version should correspond to a [tag for the node docker image](https://hub.docker.com/_/node). E.g. 10.24.1. Defaults to `latest`. |
|NPM_PUBLISH_ARGS | N | Include arguments for `npm publish`. <br> E.g. "--dry-run". |
|NPM_PUBLISH_TARGETS | N | Zipped file or folder to publish to Nexus Repo. Publishes '.' if no target/s is supplied.|

### CICD Settings/Variables to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|NEXUS_REPO_USERNAME | Y | Service account username required to authenticate with Nexus Repo.|
|NEXUS_REPO_PASSWORD | Y | Service account password required to authenticate with Nexus Repo. Use `$` key to escape special characters like `$` if necessary.|

### Known issue/s:
NA

### Reference/s:
* [Npm publish](https://docs.npmjs.com/cli/v8/commands/npm-publish)

### Template: .publish-nuget-artefact-using-nuget-cli

### Target user:

This template allows users to publish NuGet artefact to SHIP's Nexus Repo using NuGet CLI. This template leverages on [.configure-publish-nuget-for-nexus-using-nuget-cli](#template-configure-publish-nuget-for-nexus-using-nuget-cli) to use SHIP's Nexus Repo as source URL in the "before_script" key and publishes the artefact in the "script" key for a job.

### Add on implementation should go in:

* after_script

### See example/s:

* Nexus-Pull-And-Publish-NuGet-Windows: [Sample usage code](../gitlab-ci/Nexus-Pull-And-Publish-NuGet-Windows.yml) and [Documentation](../gitlab-ci#example-nexus-pull-and-publish-nuget-windows)
* [supporting-apps/dotNet-framework-console-project](../supporting-apps/dotNet-framework-console-project)

### Variable/s to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|NEXUSREPO_REPO_ID  | Y | Nexus repo name (type: hosted, format: NuGet) that your team uses.|
|PACKAGE | Y | Absolute path to the package, usually end with '.nupkg'. E.g. $CI_PROJECT_DIR\\$WORKING_DIR\\dotNet-framework-console-project.1.0.0.nupkg |
|NUGET_PUSH_OPTIONS | N | Include options for `nuget push`. <br> E.g. "-Verbosity quiet". |

### CICD Settings/Variables to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|NEXUS_REPO_USERNAME | Y | Service account username required to authenticate with Nexus Repo.|
|NEXUS_REPO_PASSWORD | Y | Service account password required to authenticate with Nexus Repo. Use `$` key to escape special characters like `$` if necessary.|

### Known issues:
* Windows runners are required to run this example.

### Reference/s:
* [NuGet push](https://docs.microsoft.com/en-us/nuget/reference/cli-reference/cli-ref-push)

### Template: .publish-nuget-artefact-using-dotnet-cli

### Target user:

This template allows users to publish NuGet artefact to SHIP's Nexus Repo using dotNet CLI. This template leverages on [.configure-publish-nuget-for-nexus-using-dotnet-cli](#template-configure-publish-nuget-for-nexus-using-dotnet-cli) to use SHIP's Nexus Repo as source URL in the "before_script" key and publishes the artefact in the "script" key for a job.

### Add on implementation should go in:

* after_script

### See example/s:

* Nexus-Pull-And-Publish-NuGet: [Sample usage code](../gitlab-ci/Nexus-Pull-And-Publish-NuGet.yml) and [Documentation](../gitlab-ci#example-nexus-pull-and-publish-nuget)
* [supporting-apps/dotNet-core-console-project](../supporting-apps/dotNet-core-console-project)

### Variable/s to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|NEXUSREPO_REPO_ID | Y | Nexus repo name (type: hosted, format: NuGet) that your team uses.|
|PACKAGE | Y | Absolute path to the package, usually end with '.nupkg'. E.g. $CI_PROJECT_DIR/$WORKING_DIR/bin/Debug/dotNet-core-console-project.1.0.0.nupkg |
|DOTNET_NUGET_PUSH_OPTIONS | N | Include options for `dotnet nuget push`. <br> E.g. "-d"; to disable buffering when pushing to a HTTP(S) server. |

### CICD Settings/Variables to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|NEXUS_REPO_USERNAME | Y | Service account username required to authenticate with Nexus Repo.|
|NEXUS_REPO_PASSWORD | Y | Service account password required to authenticate with Nexus Repo. Use `$` key to escape special characters like `$` if necessary.|

### Known issue/s:
* mcr.microsoft.com/dotnet/sdk:latest is from public repository.

### Reference/s:
* [DotNet NuGet push](https://docs.microsoft.com/en-us/dotnet/core/tools/dotnet-nuget-push)

## File: [.gitlab-ci-check-app-readiness.yml](.gitlab-ci-check-app-readiness.yml)

### Template: .wait-for-app-and-assert-text

### Target user:

This template allows users to check if a web application is ready by querying the URL and searching for a given text in a loop until a given wait duration.

### Add on implementation should go in:

* before_script
* after_script

### See example/s:

* Azcli-Invoke: [Sample usage code](../gitlab-ci/Azcli-Invoke.yml) and [Documentation](../gitlab-ci#example-azcli-invoke)
* [ctmo/reference-pipelines/netapp](https://sgts.gitlab-dedicated.com/WOG/GVT/ctmo/reference-pipelines/netapp)

### Variable/s to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|URL | Y | URL of the web application. |
|TEXT | Y | Text to search for in the given URL. |
|WAIT | N | Wait duration before failing the job. Defaults to 120s if not supplied. |

### CICD Settings/Variables to set:
NA

### Known issue/s:
NA

### Reference/s:
NA

### Template: .wait-for-docker-services

### Target user:

This template allows users to define the services to facilitate runtime testing on the docker image on Private Registry in "before_script" key. It leverages on the "script" key of [.wait-for-app-and-assert-text](#template-wait-for-app-and-assert-text) to check if a docker application is ready by querying the URL and searching for a given text in a loop until a given wait duration. The list of services should be added under `.docker-services` job in your .gitlab-ci.yml. The default `.docker-services` job in this template points to a non-existing service which will fail the job if it is not overridden in your .gitlab-ci.yml.

### Add on implementation should go in:

* script
* after_script

### See example/s:

* Readiness-Check-For-Docker-Service: [Sample usage code](../gitlab-ci/Readiness-Check-For-Docker-Service.yml) and [Documentation](../gitlab-ci#example-readiness-check-for-docker-service)
* [supporting-apps/simple-docker-app](../supporting-apps/simple-docker-app)

### Variable/s to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|URL | Y | URL of the web application. |
|TEXT | Y | Text to search for in the given URL. |
|WAIT | N | Wait duration before failing the job. Defaults to 120s if not supplied. |

### CICD Settings/Variables to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|DOCKER_AUTH_CONFIG | N | {"auths": { "Provide your docker private registry here": { "auth": "Provide base64 encoded username and password here, use escape keys if necessary. See [how](#base64-encoding) to do it." } } }. Not required if the images in `.docker-services` are from public repositories. |

### Known issue/s:
NA

### Reference/s:
NA

## File: [.gitlab-ci-azure.yml](.gitlab-ci-azure.yml)

### Template: .invoke-azcli-commands-with-serviceprincipal

### Target user:

This template allows users to invoke Azure CLI commands, which should be defined in the "script" key. This template performs login using service principal in the "before_script" key and logout in the "after_script" key.

### Add on implementation should go in:

* script

### See example/s:

* Azcli-Invoke: [Sample usage code](../gitlab-ci/Azcli-Invoke.yml) and [Documentation](../gitlab-ci#example-azcli-invoke)
* [ctmo/reference-pipelines/netapp](https://sgts.gitlab-dedicated.com/WOG/GVT/ctmo/reference-pipelines/netapp)

### Variable/s to set:
NA

### CICD Settings/Variables to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|AZ_SERVICEPRINCIPAL_ID | Y | Azure service principal user ID. |
|AZ_SERVICEPRINCIPAL_PASSWORD | Y | Azure service principal password or certificate. |
|AZ_TENANT_ID | Y | Azure subscription tenant ID. |

### Known issue/s:
NA

### Reference/s:
* [Sign in with Azure CLI](https://docs.microsoft.com/en-us/cli/azure/authenticate-azure-cli)

## File: [.gitlab-ci-aws.yml](.gitlab-ci-aws.yml)

### Template: .invoke-awscli-commands-with-assumerole

### Prerequisites:

Prior to using this template, you need to set up the identity provider using this tutorial: https://docs.gitlab.com/ee/ci/cloud_services/aws
Steps [Add the identity provider](https://docs.gitlab.com/ee/ci/cloud_services/aws/#add-the-identity-provider) and [Configure a role and trust](https://docs.gitlab.com/ee/ci/cloud_services/aws/#configure-a-role-and-trust) are required.

### Target user:

This template allows users to invoke aws cli within the "script" key. It performs assume role using an identity provider in the "before_script" key and flushes all access variables in the "after_script" key.

### Add on implementation should go in:

* script

### See example/s:

* Awscli-Invoke: [Sample usage code](../gitlab-ci/Awscli-Invoke.yml) and [Documentation](../gitlab-ci#example-awscli-invoke)

### Variable/s to set:
NA

### CICD Settings/Variables to set:
| Key       |Required |Description                                         |
|-----------|-----------|--------------------------------------------------|
| ROLE_ARN  | Y | AWS role arn of the role to be assumed.             |

### Known issue/s:
NA

### Reference/s:
* [Sign in with AWS CLI](https://docs.aws.amazon.com/cli/latest/reference/sts/assume-role-with-web-identity.html)
* [How to configure a IDP and trust for assume role based access](https://docs.gitlab.com/ee/ci/cloud_services/aws/#configure-a-role-and-trust)
* [Step by step guide with screenshots](https://confluence.ship.gov.sg/display/SHIP/Gitlab+runner+assume+role)

### Template: .invoke-awssecretretrieval

### Prerequisites:

Prior to using this template, you need to set up the identity provider using this tutorial: https://docs.gitlab.com/ee/ci/cloud_services/aws
Steps [Add the identity provider](https://docs.gitlab.com/ee/ci/cloud_services/aws/#add-the-identity-provider) and [Configure a role and trust](https://docs.gitlab.com/ee/ci/cloud_services/aws/#configure-a-role-and-trust) are required.
IAM role requires at least secretsmanager:GetSecretValue IAM permission towards the AWS secret.

### Target user:

This template allows users to invoke aws cli within the "script" key. It performs assume role using an identity provider in the "before_script" key and flushes all access variables in the "after_script" key.

### Add on implementation should go in:

* script

### See example/s:

* Aws-Secret-Retrieval: [Sample usage code](../gitlab-ci/Aws-Secret-Retrieval.yml) and [Documentation](../gitlab-ci#example-aws-secret-retrieval)

### Variable/s to set:
NA

### CICD Settings/Variables to set:
| Key        | Required | Description                  |
|------------|----------|------------------------------|
| ROLE_ARN   | Y | AWS role arn of the role to be assumed.                                     |
| SECRET_ID  | Y | Secret ID to be retrieved, required only for secrets retrieval.  |

### Known issue/s:
NA

### Reference/s:
* [Sign in with AWS CLI](https://docs.aws.amazon.com/cli/latest/reference/sts/assume-role-with-web-identity.html)
* [How to configure a IDP and trust for assume role based access](https://docs.gitlab.com/ee/ci/cloud_services/aws/#configure-a-role-and-trust)
* [Step by step guide with screenshots](https://confluence.ship.gov.sg/display/SHIP/Gitlab+runner+assume+role)

### Template: .invoke-kubectlupdateconfig

### Prerequisites:

Prior to using this template, you need to set up the identity provider using this tutorial: https://docs.gitlab.com/ee/ci/cloud_services/aws
Steps [Add the identity provider](https://docs.gitlab.com/ee/ci/cloud_services/aws/#add-the-identity-provider) and [Configure a role and trust](https://docs.gitlab.com/ee/ci/cloud_services/aws/#configure-a-role-and-trust) are required.
The configured role must have at least DescribeCluster iam permission towards the target cluster and have the required permissions in the eks's auth-config(https://docs.aws.amazon.com/eks/latest/userguide/add-user-role.html).

### Target user:

This template allows users to invoke kubectl commands within the "script" key.  It performs assume role using an identity provider in the "before_script" key, initiates a command to create the kubeconfig file to be used by kubectl and flushes all access variables in the "after_script" key.

### Add on implementation should go in:

* script

### See example/s:

* Kubectl-Invoke: [Sample usage code](../gitlab-ci/Kubectl-Invoke.yml) and [Documentation](../gitlab-ci#example-kubectl-invoke)
* [supporting-apps/helloworld-manifest](../supporting-apps/helloworld-manifest)

### Variable/s to set:
NA

### CICD Settings/Variables to set:
| Key       |Required | Description                                         |
|-----------|---------|-----------------------------------------------------|
| ROLE_ARN  | Y | AWS role arn of the role to be assumed. Note that the role needs to have minimal role of administering the EKS Cluster. See reference "Providing IAM role permissions for the EKS cluster" for more information.            |
| CLUSTER_NAME  | Y | AWS eks cluster name to be configured.             |

### Known issue/s:
NA

### Reference/s:
* [Sign in with AWS CLI](https://docs.aws.amazon.com/cli/latest/reference/sts/assume-role-with-web-identity.html)
* [How to configure a IDP and trust for assume role based access](https://docs.gitlab.com/ee/ci/cloud_services/aws/#configure-a-role-and-trust)
* [Step by step guide with screenshots](https://confluence.ship.gov.sg/display/SHIP/Gitlab+runner+assume+role)
* [Providing IAM role permissions for the EKS cluster](https://docs.aws.amazon.com/eks/latest/userguide/add-user-role.htm)

### Template: .invoke-ecr-token-retrieval

### Prerequisites:

Prior to using this template, you need to set up the identity provider using this tutorial: https://docs.gitlab.com/ee/ci/cloud_services/aws
Steps [Add the identity provider](https://docs.gitlab.com/ee/ci/cloud_services/aws/#add-the-identity-provider) and [Configure a role and trust](https://docs.gitlab.com/ee/ci/cloud_services/aws/#configure-a-role-and-trust) are required.

### Target user:

This template allows users to retrieve an AWS ECR token in "before_script" key and flushes all access tokens in the "after_script" key.

### Add on implementation should go in:

* script

### See example/s:

* Container-Signing: [Sample usage code](../gitlab-ci/Container-Signing.yml) and [Documentation](../gitlab-ci#example-container-signing)
* [supporting-apps/simple-docker-image](../supporting-apps/simple-docker-image)

### Variable/s to set:
NA

### CICD Settings/Variables to set:
| Key       |Required |Description                                         |
|-----------|-----------|--------------------------------------------------|
| AWS_ECR_URL  | Y | Amazon ECR registry URI.             |
| ROLE_ARN  | Y | AWS role arn of the role to be assumed.             |

### Known issue/s:
NA

### Reference/s:
* [Sign in with AWS CLI](https://docs.aws.amazon.com/cli/latest/reference/sts/assume-role-with-web-identity.html)
* [How to configure a IDP and trust for assume role based access](https://docs.gitlab.com/ee/ci/cloud_services/aws/#configure-a-role-and-trust)
* [Step by step guide with screenshots](https://confluence.ship.gov.sg/display/SHIP/Gitlab+runner+assume+role)
* [AWS ECR Private Registry Authentication](https://docs.aws.amazon.com/AmazonECR/latest/userguide/registry_auth.html)

## File: [.gitlab-ci-nexus-iq-scan.yml](.gitlab-ci-nexus-iq-scan.yml)

### Template: .nexus-iq-scan

### Target user:

This template allows users to perform nexus iq scan on archives or directories. This template performs nexus iq scan in the "script" key.

### Add on implementation should go in:

* before_script
* after_script

### See example/s:

* Nexus-Pull-Scan-And-Publish-NPM: [Sample usage code](../gitlab-ci/Nexus-Pull-Scan-And-Publish-NPM.yml) and [Documentation](../gitlab-ci#example-nexus-pull-scan-and-publish-npm)
* [supporting-apps/nodejs-simple-library](../supporting-apps/nodejs-simple-library)

### Variable/s to set:
|Key             |Required |Description |
|----------------|-----------|-----------|
|NEXUS_IQ_APP_ID | Y | ID of the application on the Nexus IQ.|
|SCAN_TARGETS  | Y | Archives or directories to scan. For multiple build artifacts, the archives or directories can be separated by ';' <br> E.g. "web-module/target/our-web-app.war;lib-module/target/our-shared-lib.jar".|
|NEXUS_IQ_SCAN_OPTIONS  | N | Include options, except for application id (-i), for nexus iq scan. <br> E.g. "-r nexus-iq-result.json"; with path to JSON file where the results of the policy evaluation will be stored.|

### CICD Settings/Variables to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|NEXUS_IQ_USERNAME        | Y | Service account username with permission (i.e. assigned Application Evaluator role) to invoke Nexus IQ evaluation for the application and to authenticate with Nexus IQ. |
|NEXUS_IQ_PASSWORD        | Y | Service account password to authenticate with Nexus IQ. |

### Known issue/s:
NA

### Reference/s:
* [Gitlab Nexus IQ Pipeline](https://hub.docker.com/r/sonatype/gitlab-nexus-iq-pipeline)
* [Considerations for using Nexus IQ](https://confluence.ship.gov.sg/display/GSSC/Considerations+for+using+Nexus+IQ)

## File: [.gitlab-ci-nexus-configure.yml](.gitlab-ci-nexus-configure.yml)

### Template: .configure-npm-for-nexus

### Target user:

This template allows users to set SHIP's Nexus Repo as npm config registry in the "before_script". `npm ci` and `npm install` commands can be used as add-on implementation to install dependency library packages from SHIP's Nexus Repo.

### Add on implementation should go in:

* script
* after_script

### See example/s:

* Nexus-Pull-Scan-And-Publish-NPM: [Sample usage code](../gitlab-ci/Nexus-Pull-Scan-And-Publish-NPM.yml) and [Documentation](../gitlab-ci#example-nexus-pull-scan-and-publish-npm)
* [supporting-apps/nodejs-simple-library](../supporting-apps/nodejs-simple-library)

### Variable/s to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|NEXUSREPO_REPO_ID| Y | Nexus repo name (type: group, format: npm) that your team uses.|
|NODE_VERSION | N |  Node version to use; this version should correspond to a [tag for the node docker image](https://hub.docker.com/_/node). E.g. 10.24.1. Defaults to `latest`. |

### CICD Settings/Variables to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|NEXUS_REPO_USERNAME | Y | Service account username required to authenticate with Nexus Repo.|
|NEXUS_REPO_PASSWORD | Y | Service account password required to authenticate with Nexus Repo. Use `$` key to escape special characters like `$` if necessary.|

### Known issue/s:
NA

### Reference/s:
NA

### Template: .configure-publish-nuget-for-nexus-using-nuget-cli

### Target user:

This template allows users to setup nuget.config file in $CI_PROJECT_DIR\\Nexus_NuGet_Config folder and add SHIP's Nexus Repo as source URL in the "before_script" key using NuGet CLI. It is used by [.publish-nuget-artefact-using-nuget-cli](#template-publish-nuget-artefact-using-nuget-cli), where `nuget push` is added in "script" key to publish NuGet artefact to SHIP's Nexus Repo using NuGet CLI.

### Add on implementation should go in:

* script
* after_script

### See example/s:

* Nexus-Pull-And-Publish-NuGet-Windows: [Sample usage code](../gitlab-ci/Nexus-Pull-And-Publish-NuGet-Windows.yml) and [Documentation](../gitlab-ci#example-nexus-pull-and-publish-nuget-windows)
* [supporting-apps/dotNet-framework-console-project](../supporting-apps/dotNet-framework-console-project)

### Variable/s to set:
|Key             | Required | Description|
|----------------|-----------|-----------|
|NEXUSREPO_REPO_ID| Y | Nexus repo name (type: hosted, format: NuGet) that your team uses.|

### CICD Settings/Variables to set:
|Key             | Required | Description|
|----------------|-----------|-----------|
|NEXUS_REPO_USERNAME | Y | Service account username required to authenticate with Nexus Repo.|
|NEXUS_REPO_PASSWORD | Y | Service account password required to authenticate with Nexus Repo. Use `$` key to escape special characters like `$` if necessary.|

### Known issues:
* Windows runners are required to run this example.

### Reference/s:
NA

### Template: .configure-publish-nuget-for-nexus-using-dotnet-cli

### Target user:

This template allows users to setup nuget.config file in $CI_PROJECT_DIR/Nexus_NuGet_Config folder and add SHIP's Nexus Repo as source URL in the "before_script" key using dotNet CLI. It is used by [.publish-nuget-artefact-using-dotnet-cli](#template-publish-nuget-artefact-using-dotnet-cli), where `dotnet nuget push` is added in "script" key to publish NuGet artefact to SHIP's Nexus Repo using dotNet CLI.

### Add on implementation should go in:

* script
* after_script

### See example/s:

* Nexus-Pull-And-Publish-NuGet: [Sample usage code](../gitlab-ci/Nexus-Pull-And-Publish-NuGet.yml) and [Documentation](../gitlab-ci#example-nexus-pull-and-publish-nuget)
* [supporting-apps/dotNet-core-console-project](../supporting-apps/dotNet-core-console-project)

### Variable/s to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|NEXUSREPO_REPO_ID| Y | Nexus repo name (type: hosted, format: NuGet) that your team uses.|

### CICD Settings/Variables to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|NEXUS_REPO_USERNAME | Y | Service account username required to authenticate with Nexus Repo.|
|NEXUS_REPO_PASSWORD | Y | Service account password required to authenticate with Nexus Repo. Use `$` key to escape special characters like `$` if necessary.|

### Known issue/s:
* mcr.microsoft.com/dotnet/sdk:latest is from public repository.

### Reference/s:
NA

## File: [.gitlab-ci-run-test.yml](.gitlab-ci-run-test.yml)

### Template: .run-robot-test

### Target user:

This template allows users to run integration testing with the robot framework and generate individual reports all inside $OUTPUT_DIR provided.

### Add on implementation should go in:

* before_script
* after_script

### See example/s:

* Robot-Framework-Test-And-Report: [Sample usage code](../gitlab-ci/Robot-Framework-Test-And-Report.yml) and [Documentation](../gitlab-ci#example-robot-framework-test-and-report)
* [supporting-apps/robot-framework-testsuite](../supporting-apps/robot-framework-testsuite/)
* Pcloudy-Test-App: [Sample usage code](../gitlab-ci/Pcloudy-Test-App.yml) and [Documentation](../gitlab-ci#example-pcloudy-test-app)
* Pcloudy-Test-Browser: [Sample usage code](../gitlab-ci/Pcloudy-Test-Browser.yml) and [Documentations](../gitlab-ci#example-pcloudy-test-browser)
* [supporting-apps/pcloudy-resources](../supporting-apps/pcloudy-resources)

### Variable/s to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|OPTS | Y | Robot command options and arguments. Refer to "Robot Command Options" in Reference/s.|
|OUTPUT_DIR | Y | Directory for report outputs for both .xml AND .html.|
|OUTPUT_XML | Y | Filename for XML report (mostly for tools integration and report consolidation by Rebot). E.g output.xml.|
|LOG_NAME | Y | Filename for test logs in HTML format. E.g log.html or just log (without extention)|
|REPORT_NAME | Y | Filename for report in HTML format. E.g report.html or just report (without extention)|
|TEST_TARGET | Y | Location of robot test file.|
|SERVICE| N | Selenium web browser services. Examples are `selenium/standalone-chrome:4`, `selenium/standalone-firefox:4`, etc. Refer to https://github.com/SeleniumHQ/docker-selenium for more options.|
|ROBOT_IMAGE_VERSION | N | Robot framework image version. Defaults to `latest`. |

### CICD Settings/Variables to set:
NA

### Known issue/s:
NA

### Reference/s:
* [Robot Framework User Guide](https://robotframework.org/robotframework/latest/RobotFrameworkUserGuide.html#robot)
* [Robot Command Options](https://robot-framework.readthedocs.io/en/v4.1.2/_modules/robot/run.html)

## File: [.gitlab-ci-create-report.yml](.gitlab-ci-create-report.yml)

### Template: .generate-robot-consolidated-report

### Target user:

This template allows users to consolidate test report files and export the final html report from robot tests as an artifact. Note that if there are multiple test suites being ran beforehand, the names of the $OUTPUT_XML files must be different so as not to be overwritten.

### Add on implementation should go in:

* before_script
* after_script

### See example/s:

* Robot-Framework-Test-And-Report: [Sample usage code](../gitlab-ci/Robot-Framework-Test-And-Report.yml) and [Documentation](../gitlab-ci#example-robot-framework-test-and-report)
* [supporting-apps/robot-framework-testsuite](../supporting-apps/robot-framework-testsuite/)

### Variable/s to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|OPTS | Y | Rebot command options and arguments. Refer to "Rebot Command Options" in Reference/s.|
|OUTPUT_DIR | Y | Directory for report outputs for both .xml AND .html.|
|REPORT_TARGET | Y | Path to individual XML reports for consolidation.|
|ROBOT_IMAGE_VERSION | N | Robot framework image version. Defaults to `latest`. |

### CICD Settings/Variables to set:
NA

### Known issue/s:
NA

### Reference/s:
* [Robot Framework User Guide](https://robotframework.org/robotframework/latest/RobotFrameworkUserGuide.html#rebot)
* [Rebot Command Options](https://robot-framework.readthedocs.io/en/latest/_modules/robot/rebot.html)

## File: [.gitlab-ci-nodejs-common.yml](.gitlab-ci-nodejs-common.yml)

### Template: .npm-depcheck

### Target user:

This template allows users to perform depcheck for their npm projects to identify unused dependencies.

### Add on implementation should go in:

* after_script

### See example/s:

* Nexus-Pull-Scan-And-Publish-NPM: [Sample usage code](../gitlab-ci/Nexus-Pull-Scan-And-Publish-NPM.yml) and [Documentation](../gitlab-ci#example-nexus-pull-scan-and-publish-npm)
* [supporting-apps/nodejs-simple-library](../supporting-apps/nodejs-simple-library)
* [ctmo/reference-pipelines/nodetsapp](https://sgts.gitlab-dedicated.com/WOG/GVT/ctmo/reference-pipelines/nodetsapp)

### Variable/s to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|WORKING_DIR| N |Path of npm project - default to "."|
|BLOCK_UNUSED_DEV_DEP| N |0 or 1. If 1, fail the job if there is any unused development dependencies - Default to 0.|
|NODE_VERSION| N |Node version to use; this version should correspond to a [tag for the Pipeline COE node docker image](https://sgts.gitlab-dedicated.com/pipeline-coe/node-jq/container_registry/260). Defaults to `latest`.|

### CICD Settings/Variables to set:
NA

### Known issue/s:
* The template uses a runner with tag "ship" as it requires installation of jq to parse the depcheck json report. TODO: Template to switch to a pipeline coe image (once available) with jq installed.

### Reference/s:
NA

## File: [.gitlab-ci-aquasec-trivy-scan.yml](.gitlab-ci-aquasec-trivy-scan.yml)

### Template: .trivy-scan

### Target user:

This template allows users to scan an image in a .tar or .tar.gz format, or from a remote image registry, using Aquasec Trivy and generate a Gitlab UI-compatible report.

### Add on implementation should go in:

* before_script
* after_script

### See example/s:

* Aquasec-Trivy-Scan-File: [Sample usage code](../gitlab-ci/Aquasec-Trivy-Scan-File.yml) and [Documentation](../gitlab-ci#example-aquasec-trivy-scan-file)
* Aquasec-Trivy-Scan-Private-Repo: [Sample usage code](../gitlab-ci/Aquasec-Trivy-Scan-Private-Repo.yml) and [Documentation](../gitlab-ci#example-aquasec-trivy-scan-private-repo)
* [supporting-apps/aquasec-trivy-scan](../supporting-apps/aquasec-trivy-scan)

### Variable/s to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|SCAN_TARGET| Y | Path to the file to be scanned or image registry URL|
|REPORT_LEVELS| Y | Vulnerability levels to be shown in the report. Comma separated values without whitespace Eg. LOW,MEDIUM,HIGH (Possible values: UNKNOWN, LOW, MEDIUM, HIGH, CRITICAL)|
|FAIL_LEVELS| Y | Vulnerability levels that on detection, will result in pipeline failure and exit. Comma separated values without whitespace Eg. LOW,MEDIUM,HIGH (Possible values: UNKNOWN, LOW, MEDIUM, HIGH, CRITICAL)|
|REPORT_NAME| N | Name for GitLab UI-compatible report generated. If not specified, defaults to 'trivy-scan-report' |
|TRIVY_VERSION| N | Trivy version to use; this version should correspond to a [tag for the trivy docker image](https://hub.docker.com/r/aquasec/trivy/tags). E.g. latest |

### CICD Settings/Variables to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|TRIVY_USERNAME| N | Username of user account in the private image registry, for Trivy to authenticate with when scanning private images (Built-in Trivy variable that is automatically referenced, only required for private image registries)|
|TRIVY_PASSWORD| N | Password of user account in the private image registry, for Trivy to authenticate with when scanning private images (Built-in Trivy variable that is automatically referenced, only required for private image registries)|

### Known issue/s:
* In the Security tab of the triggered child pipeline, there is a warning "'/version' does not match pattern". It does not affect the scan.

### Reference/s:
* [Aquasec Trivy Documentation (v0.28.0)](https://aquasecurity.github.io/trivy/v0.28.0/docs/references/cli/image/)

## File: [.gitlab-ci-container-signing.yml](.gitlab-ci-container-signing.yml)

### Template: .sign-container

### Target user:

This template allows users to sign image in an OCI registry

### Add on implementation should go in

* before_script
* after_script

### See example/s:

* Container-Signing: [Sample usage code](../gitlab-ci/Container-Signing.yml) and [Documentation](../gitlab-ci#example-container-signing)
* [supporting-apps/simple-docker-image](../supporting-apps/simple-docker-image)

### Variable/s to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|IMAGE_VERSION| Y | Target image version to be signed.|
|DOCKER_REGISTRY| Y | Docker registry that stores the image to be signed. [DOCKER_AUTH_CONFIG](https://docs.gitlab.com/ee/ci/docker/using_docker_images.html#access-an-image-from-a-private-container-registry) is required for private repositories that require authentication. |
|DIGESTFILE_NAME | N | Relative path of file having the digest string of image to sign. Defaults to "digest" if unsupplied. Alternatively, IMG_NAME_W_DIGEST can be used to specify the image name with digest.|
|IMG_NAME_W_DIGEST | N | Follows the format: 'IMAGE@DIGEST', refer to IMAGE_DIGEST variable in "Cosign Detailed Usage" under Reference/s. Required as an alternative to DIGESTFILE_NAME. |

### CICD Settings/Variables to set
|Key             |Required |Description|
|----------------|-----------|-----------|
|COSIGN_PASSWORD| Y | Password for key generation and container signing. |
|COSIGN_KEY| N | BYO private key if not using current template way of generating on-the-fly. |
|DOCKER_AUTH_CONFIG| N | {"auths": { "$DOCKER_REGISTRY": { "auth": "Provide base64 encoded username and password here, use escape keys if necessary. See [how](#base64-encoding) to do it." } } }. To authenticate with an OCI registry. This template checks for docker config.json file which is created upon docker login or passed in as an artifact from previous job. In such cases, this variable would not be required. |
|DOCKER_USER | N | Docker username to use as an alternative to DOCKER_AUTH_CONFIG. For AWS ECR, it can be "AWS". |
|DOCKER_PASSWORD | N | Docker password to use as an alternative to DOCKER_AUTH_CONFIG. For AWS ECR, it can be ECR token generated by [.invoke-ecr-token-retrieval](#template-invoke-ecr-token-retrieval). |

### Known issue/s:
NA

### Reference/s:
* [Sigstore Documentation](https://docs.sigstore.dev/)
* [Cosign Detailed Usage](https://github.com/sigstore/cosign/blob/main/USAGE.md#detailed-usage)

### Template: .verify-container

### Target user:

This template allows users to verify image in an OCI registry.

### Add on implementation should go in

* before_script
* after_script

### See example/s:

* Container-Signing: [Sample usage code](../gitlab-ci/Container-Signing.yml) and [Documentation](../gitlab-ci#example-container-signing)
* [supporting-apps/simple-docker-image](../supporting-apps/simple-docker-image)

### Dependencies:

* Requires Public Key artefact from [.sign-container](#template-sign-container) job

### Variable/s to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|IMAGE_NAME| Y | Target image name to be verified.|
|IMAGE_VERSION| Y | Target image version to be verified.|
|DOCKER_REGISTRY| Y | Docker registry that stores the image to be verified. [DOCKER_AUTH_CONFIG](https://docs.gitlab.com/ee/ci/docker/using_docker_images.html#access-an-image-from-a-private-container-registry) is required for private repositories that require authentication. |

### CICD Settings/Variables to set
|Key             |Required |Description|
|----------------|-----------|-----------|
|COSIGN_PUB| N | BYO public key matching to the signature. Alternatively, can use cache / needs to include a cosign.pub file. Otherwise if using current template way of generating on-the-fly, the sign job would export cosign.pub as artifact for this verification, no need to supply. |
|DOCKER_AUTH_CONFIG| N | {"auths": { "$DOCKER_REGISTRY": { "auth": "Provide base64 encoded username and password here, use escape keys if necessary. See [how](#base64-encoding) to do it." } } }. To authenticate with an OCI registry. This template checks for docker config.json file which is created upon docker login or passed in as an artifact from previous job. In such cases, this variable would not be required. |
|DOCKER_USER | N | Docker username to use as an alternative to DOCKER_AUTH_CONFIG. For AWS ECR, it can be "AWS". |
|DOCKER_PASSWORD | N | Docker password to use as an alternative to DOCKER_AUTH_CONFIG. For AWS ECR, it can be ECR token generated by [.invoke-ecr-token-retrieval](#template-invoke-ecr-token-retrieval). |

### Known issue/s:
NA

### Reference/s:
* [Sigstore Documentation](https://docs.sigstore.dev/)

## File: [.gitlab-ci-blob-signing.yml](.gitlab-ci-blob-signing.yml)

### Template: .sign-artifact

### Target user:

This template allows users to sign standard files.

### Add on implementation should go in:

* before_script
* after_script

### See example/s:

* Blob-Signing: [Sample usage code](../gitlab-ci/Blob-Signing.yml) and [Documentation](../gitlab-ci#example-blob-signing)
* [supporting-apps/helloworld-manifest](../supporting-apps/helloworld-manifest)
* Maven-Artefact-Checksum-Verification: [Sample usage code](../gitlab-ci/Maven-Artefact-Checksum-Verification.yml) and [Documentation](../gitlab-ci#example-maven-artefact-checksum-verification)
* [supporting-apps/maven-simple-app](../supporting-apps/maven-simple-app)

### Variable/s to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|ARTIFACT_NAME| Y | Target artifact name to be signed and verified|
|SIGNATURE_FILE| Y | File name to store the signature after file signing. This file is required for verification|

### CICD Settings Variable/s to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|COSIGN_PASSWORD| Y | Password for key generation and blob signing. |
|COSIGN_KEY| N | BYO private key if not using current template way of generating on-the-fly. |

### Known issue/s:
NA

### Reference/s:
* [Sigstore Documentation](https://docs.sigstore.dev/)

### Template: .verify-artifact

### Target user:

This template allows users to verify signed standard files.

### Add on implementation should go in:

* before_script
* after_script

### See example/s:

* Blob-Signing: [Sample usage code](../gitlab-ci/Blob-Signing.yml) and [Documentation](../gitlab-ci#example-blob-signing)
* [supporting-apps/helloworld-manifest](../supporting-apps/helloworld-manifest)

### Variable/s to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|ARTIFACT_NAME| Y | Target artifact name to be signed and verified|
|SIGNATURE_FILE| Y | File name to store the signature after file signing. This file is required for verification|

### CICD Settings Variable/s to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|COSIGN_PUB| N | BYO public key matching to the signature. Alternatively, can use cache / needs to include a cosign.pub file. Otherwise if using current template way of generating on-the-fly, the sign job would export cosign.pub as artifact for this verification, no need to supply. |

### Known issue/s:
NA

### Reference/s:
* [Sigstore Documentation](https://docs.sigstore.dev/)

## File: [.gitlab-ci-pcloudy-test.yml](.gitlab-ci-pcloudy-test.yml)

### Template: .hatspcloudycli-upload

### Target user:

This template allows users upload an application file to Pcloudy.

### Add on implementation should go in:

* before_script
* after_script

### See example/s:

* Pcloudy-Test-App: [Sample usage code](../gitlab-ci/Pcloudy-Test-App.yml) and [Documentation](../gitlab-ci#example-pcloudy-test-app)
* [supporting-apps/pcloudy-resources](../supporting-apps/pcloudy-resources)

### Variable/s to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|PCLOUDY_UPLOAD_FILE_PATH| Y | File path of the target file to upload|

### CICD Settings/Variables to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|PCLOUDY_TOKEN | Y | Pcloudy subscription token retrieved from SHIP-HATS Portal|

### Known issue/s:
NA

### Reference/s:
* [Pcloudy CLI documentation](https://confluence.ship.gov.sg/display/HATSKB/pCloudy+CLI)

### Template: .hatspcloudycli-book-app

### Target user:

This template allows users to book a device on Pcloudy for application file testing.

### Add on implementation should go in:

* before_script
* after_script

### See example/s:

* Pcloudy-Test-App: [Sample usage code](../gitlab-ci/Pcloudy-Test-App.yml) and [Documentation](../gitlab-ci#example-pcloudy-test-app)
* [supporting-apps/pcloudy-resources](../supporting-apps/pcloudy-resources)

### Dependencies:
* An application file should be uploaded first, using the previous template [.hatspcloudycli-upload](#template-hatspcloudycli-upload)

### Variable/s to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|PCLOUDY_BOOK_DEVICE_ARGS| Y | additional arguments for the pcloudy CLI, such as duration (`-d`) or platform (`-p`). See [Pcloudy CLI documentation](https://confluence.ship.gov.sg/display/HATSKB/pCloudy+CLI) for more details|
|PCLOUDY_UPLOADED_FILE_RESULT| N |This should be automatically set if you use the previous template [.hatspcloudycli-upload](#template-hatspcloudycli-upload)|

### CICD Settings/Variables to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|PCLOUDY_TOKEN | Y | Pcloudy subscription token retrieved from SHIP-HATS Portal|

### Known issue/s:
NA

### Reference/s:
* [Pcloudy CLI documentation](https://confluence.ship.gov.sg/display/HATSKB/pCloudy+CLI)

### Template: .hatspcloudycli-book-browser

### Target user:

This template allows users to book a device on Pcloudy for browser testing

### Add on implementation should go in:

* before_script
* after_script

### See example/s:

* Pcloudy-Test-Browser: [Sample usage code](../gitlab-ci/Pcloudy-Test-Browser.yml) and [Documentation](../gitlab-ci#example-pcloudy-test-browser)
* [supporting-apps/pcloudy-resources](../supporting-apps/pcloudy-resources)

### Variable/s to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|PCLOUDY_BOOK_DEVICE_ARGS| Y |Additional arguments for the pcloudy CLI, such as duration (`-d`) or platform (`-p`). See [Pcloudy CLI documentation](https://confluence.ship.gov.sg/display/HATSKB/pCloudy+CLI) for more details|

### CICD Settings/Variables to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|PCLOUDY_TOKEN | Y |Pcloudy subscription token retrieved from SHIP-HATS Portal|

### Known issue/s:
NA

### Reference/s:
* [Pcloudy CLI documentation](https://confluence.ship.gov.sg/display/HATSKB/pCloudy+CLI)

### Template: .hatspcloudycli-download-logs

### Target user:

This template allows users to download Pcloudy log files after tests are complete

### Add on implementation should go in:

* before_script
* after_script

### See example/s:

* Pcloudy-Test-App: [Sample usage code](../gitlab-ci/Pcloudy-Test-App.yml) and [Documentation](../gitlab-ci#example-pcloudy-test-app)
* Pcloudy-Test-Browser: [Sample usage code](../gitlab-ci/Pcloudy-Test-Browser.yml) and [Documentation](../gitlab-ci#example-pcloudy-test-browser)
* [supporting-apps/pcloudy-resources](../supporting-apps/pcloudy-resources)

### Dependencies:
* A Pcloudy device should be booked first, using the previous template [.hatspcloudycli-book-app](#template-hatspcloudycli-book-app) or [.hatspcloudycli-book-browser](#template-hatspcloudycli-book-browser)

### Variable/s to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|PCLOUDY_BOOK_DEVICE_RESULT| N |this should be automatically set if you use the previous template [.hatspcloudycli-book-app](#template-hatspcloudycli-book-app) or [.hatspcloudycli-book-browser](#template-hatspcloudycli-book-browser)|

### CICD Settings/Variables to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|PCLOUDY_TOKEN| Y | Pcloudy subscription token retrieved from SHIP-HATS Portal|

### Known issue/s:
NA

### Reference/s:
* [Pcloudy CLI documentation](https://confluence.ship.gov.sg/display/HATSKB/pCloudy+CLI)

### Template: .hatspcloudycli-release

### Target user:

This template allows users to release a booked device on Pcloudy

### Add on implementation should go in:

* before_script
* after_script

### See example/s:

* Pcloudy-Test-App: [Sample usage code](../gitlab-ci/Pcloudy-Test-App.yml) and [Documentation](../gitlab-ci#example-pcloudy-test-app)
* Pcloudy-Test-Browser: [Sample usage code](../gitlab-ci/Pcloudy-Test-Browser.yml) and [Documentations](../gitlab-ci#example-pcloudy-test-browser)
* [supporting-apps/pcloudy-resources](../supporting-apps/pcloudy-resources)

### Dependencies:
* A Pcloudy device should be booked first, using the previous template [.hatspcloudycli-book-app](#template-hatspcloudycli-book-app) or [.hatspcloudycli-book-browser](#template-hatspcloudycli-book-browser)

### Variable/s to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|PCLOUDY_BOOK_DEVICE_RESULT| N |this should be automatically set if you use the previous template [.hatspcloudycli-book-app](#template-hatspcloudycli-book-app) or [.hatspcloudycli-book-browser](#template-hatspcloudycli-book-browser)|

### CICD Settings/Variables to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|PCLOUDY_TOKEN | Y |Pcloudy subscription token retrieved from SHIP-HATS Portal|

### Known issue/s:
NA

### Reference/s:
* [Pcloudy CLI documentation](https://confluence.ship.gov.sg/display/HATSKB/pCloudy+CLI)

## File: [.gitlab-ci-run-fod-scan.yml](.gitlab-ci-run-fod-scan.yml)

### Template: .fortify-sast-fod-with-report

### Disclaimer
We strongly recommend that tenants reuse our current template instead of forking a new template. This is because there are many default values which are set in the templates which might be subjected to change in the future. Forking the template without some of the default values might cause issues down the line.

This template is solely used for running SAST on platform-agnostic programming languages such as Python, Java and etc. The default jdk version of this template is jdk 11. Please use [.scancentral-package-msbuild](#template-scancentral-package-msbuild) and [.fortify-sast-msbuild-with-report](#template-fortify-sast-msbuild-with-report) for running SAST on .NET applications.

### Prerequisites

* Only service accounts are allowed to run scans. Do ensure that you are using the credentials of your subscription's service account

### Target user:

This template allows users to do Fortify SAST and generate a Gitlab UI-compatible report.

### Add on implementation should go in:

* before_script

### See example/s:

* Fod-Sast: [Sample usage code](../gitlab-ci/Fod-Sast.yml) and [Documentation](../gitlab-ci#example-fod-sast)
* [supporting-apps/javadockerapp](../supporting-apps/javadockerapp)
* [WebGoat/v8.1.0](https://github.com/WebGoat/WebGoat/tree/v8.1.0)
* [WebGoat/v8.0.0](https://github.com/WebGoat/WebGoat/tree/v8.0.0)


### Variable/s to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|FOD_RELEASE| Y | Release ID for your FOD application|
|PACKAGE_OPTS| Y | Includes additional options on how to package your source code for various build tools such as Maven and Gradle, please refer to the [guide](https://docs.developer.tech.gov.sg/docs/ship-hats-tools/fod/fod-sast-scan?id=package-source-code-in-zip-file) on how to do so.|
|FOD_UPLOADER_OPTS| Y | Includes details of the technology stack and the language used in the code base. Please refer to the [guide](https://docs.developer.tech.gov.sg/docs/ship-hats-tools/fod/fod-sast-scan?id=upload-zip-to-fod-server-for-processing-and-scanning) on the correct values to specify for each programming language.|
|FOD_IN_PROGRESS_SCAN_ACTION| N | Includes details for a new scan if an in-progress scan exists. Please refer to the [guide](https://docs.developer.tech.gov.sg/docs/ship-hats-tools/fod/fod-sast-scan?id=upload-zip-to-fod-server-for-processing-and-scanning) on the correct value to specify. Defaults to `-pp 2`.|
|FOD_POLLING_INTERVAL| N | Includes details of the polling interval. Please refer to the [guide](https://docs.developer.tech.gov.sg/docs/ship-hats-tools/fod/fod-sast-scan?id=upload-zip-to-fod-server-for-processing-and-scanning) on the correct value to specify. Defaults to `-I 1`.|
|FOD_JDK_VERSION| N | JDK version of FOD tools image (fortify-ci-tools). Please refer to the [guide](https://docs.developer.tech.gov.sg/docs/ship-hats-tools/fod/fod-sast-scan?id=upload-zip-to-fod-server-for-processing-and-scanning) on the correct value to specify. Defaults to `11`.|

### CICD Settings/Variables to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|FOD_USERNAME| Y | Username of your service account|
|FOD_PAT| Y |Personal access token of your service account to run SAST/DAST scan|

### Usage Example/s:
#### 1. Scanning Python3 source code
* PACKAGE_OPTS="-bt none"
* FOD_UPLOADER_OPTS="-ts 10 -l 13"

#### 2. Scanning Java 11 source code with Gradle
* PACKAGE_OPTS="–bt gradle –bf build.gradle"
* FOD_UPLOADER_OPTS="-ts 7 -l 20"

#### 3. Scanning Java 11 source code with Maven
* PACKAGE_OPTS="–bt mvn"
* FOD_UPLOADER_OPTS="-ts 7 -l 20"

#### 4. Scanning Java 8 source code with Maven
* PACKAGE_OPTS="–bt mvn"
* FOD_UPLOADER_OPTS="-ts 7 -l 12"

### Known issue/s:
* [FOD SAST Scan Documentation](https://docs.developer.tech.gov.sg/docs/ship-hats-tools/fod/fod-sast-scan)

### Reference/s:
* [FOD SAST Scan Documentation](https://docs.developer.tech.gov.sg/docs/ship-hats-tools/fod/fod-sast-scan)

### Template: .fortify-dast

### Disclaimer
We strongly recommend that tenants reuse our current template instead of forking a new template. This is because there are many default values which are set in the templates which might be subjected to change in the future. Forking the template without some of the default values might cause issues down the line.

This template only triggers a DAST scan and does not reflect the fod dast scan status. Therefore, kindly head over to FOD portal to check your scan status.

### Prerequisites

* Only service accounts are allowed to run scans. Do ensure that you are using the credentials of your subscription's service account

### Target user:

This template allows users to do Fortify DAST scan on a dynamic web application.

### Add on implementation should go in:

* before_script
* after_script

### See example/s:

* Fod-Dast: [Sample usage code](../gitlab-ci/Fod-Dast.yml) and [Documentation](../gitlab-ci#example-fod-dast)

### Variable/s to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|FOD_RELEASE| Y | Release ID for your FOD application|

### CICD Settings/Variables to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|FOD_USERNAME| Y | Username of your service account|
|FOD_PAT| Y | Personal access token of your service account to run SAST/DAST scan|

### Known issue/s:
* This template only triggers a DAST scan and does not reflect the fod dast scan status. Therefore, kindly head over to FOD portal to check your scan status.
* [FOD DAST Scan Documentation](https://docs.developer.tech.gov.sg/docs/ship-hats-tools/fod/fod-dast-scan)

### Reference/s:
* [FOD DAST Scan Documentation](https://docs.developer.tech.gov.sg/docs/ship-hats-tools/fod/fod-dast-scan)

### Template: .scancentral-package-msbuild

### Disclaimer
We strongly recommend that tenants reuse our current template instead of forking a new template. This is because there are many default values which are set in the templates which might be subjected to change in the future. Forking the template without some of the default values might cause issues down the line.

This template is solely used for running SAST on .NET applications. Please use [.fortify-sast-fod-with-report](#template-fortify-sast-fod-with-report) for other platform-agnostic applications such as Python, Java and etc.

### Target user:

This template allows users use Fortify ScanCentral to package their .NET source code into a zip file for FOD SAST processing.

### Add on implementation should go in:

* before_script
* after_script

### See example/s:

* Fod-Sast-MSBuild: [Sample usage code](../gitlab-ci/Fod-Sast-MSBuild.yml) and [Documentation](../gitlab-ci#example-fod-sast-msbuild)
* [supporting-apps/msbuild-sample-app](../supporting-apps/msbuild-sample-app)

### Variable/s to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|SOLUTION_FILEPATH| Y | File path of the .sln file|

### CICD Settings/Variables to set:
NA

### Known issue/s:
* [FOD SAST Scan Documentation](https://docs.developer.tech.gov.sg/docs/ship-hats-tools/fod/fod-sast-scan)

### Reference/s:
* [FOD SAST Scan Documentation](https://docs.developer.tech.gov.sg/docs/ship-hats-tools/fod/fod-sast-scan)

### Template: .fortify-sast-msbuild-with-report

### Disclaimer
We strongly recommend that tenants reuse our current template instead of forking a new template. This is because there are many default values which are set in the templates which might be subjected to change in the future. Forking the template without some of the default values might cause issues down the line.

This template is solely used for running SAST on .NET applications. Please use [.fortify-sast-fod-with-report](#template-fortify-sast-fod-with-report) for other platform-agnostic applications such as Python, Java and etc.

### Prerequisites

* Only service accounts are allowed to run scans. Do ensure that you are using the credentials of your subscription's service account.

### Target user:

This template allows users to run Fortify SAST for .NET applications and generate a Gitlab UI-compatible report.

### Add on implementation should go in:

* before_script

### See example/s:

* Fod-Sast-MSBuild: [Sample usage code](../gitlab-ci/Fod-Sast-MSBuild.yml) and [Documentation](../gitlab-ci#example-fod-sast-msbuild)
* [supporting-apps/msbuild-sample-app](../supporting-apps/msbuild-sample-app)

### Dependencies:
* This job relies on the `.scancentral-package-msbuild` job to output a zip file for users to run Fortify SAST and generate a Gitlab UI-compatible report.

### Variable/s to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|FOD_RELEASE| Y | Release ID for your FOD application|
|FOD_UPLOADER_OPTS| Y | Includes details of the technology stack and the language used in the code base. Please refer to the [guide](https://docs.developer.tech.gov.sg/docs/ship-hats-tools/fod/fod-sast-scan?id=upload-zip-to-fod-server-for-processing-and-scanning) on the correct values to specify for each programming language.|
|FOD_IN_PROGRESS_SCAN_ACTION| N | Includes details for a new scan if an in-progress scan exists. Please refer to the [guide](https://docs.developer.tech.gov.sg/docs/ship-hats-tools/fod/fod-sast-scan?id=upload-zip-to-fod-server-for-processing-and-scanning) on the correct value to specify. Defaults to `-pp 2`.|
|FOD_POLLING_INTERVAL| N | Includes details of the polling interval. Please refer to the [guide](https://docs.developer.tech.gov.sg/docs/ship-hats-tools/fod/fod-sast-scan?id=upload-zip-to-fod-server-for-processing-and-scanning) on the correct value to specify. Defaults to `-I 1`.

### CICD Settings/Variables to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|FOD_USERNAME| Y | Username of your service account|
|FOD_PAT| Y |Personal access token of your service account to run SAST/DAST scan|

### Usage Example/s:
#### Scanning .NET applications
* FOD_UPLOADER_OPTS="-ts 1 -l 15"

### Known issue/s:
* [FOD SAST Scan Documentation](https://docs.developer.tech.gov.sg/docs/ship-hats-tools/fod/fod-sast-scan)

### Reference/s:
* [FOD SAST Scan Documentation](https://docs.developer.tech.gov.sg/docs/ship-hats-tools/fod/fod-sast-scan)

## File: [.gitlab-ci-create-fod-report.yml](.gitlab-ci-create-fod-report.yml)

### Template: .create-fod-sast-report

### Target user:

This template allows users to create SAST gitlab reports for FOD.

### Add on implementation should go in:

* before_script
* after_script

### See example/s:

* Fod-Sast-Generate-Report: [Sample usage code](../gitlab-ci/Fod-Sast-Generate-Report.yml) and [Documentation](../gitlab-ci#example-fod-sast-generate-report)

### Variable/s to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|FOD_RELEASE| Y | Release ID for your FOD application|

### CICD Settings/Variables to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|FOD_USERNAME| Y | Username of your service account|
|FOD_PAT| Y | Personal access token of your service account to run SAST/DAST scan|

### Known issue/s:
NA

### Reference/s:
NA

### Template: .create-fod-dast-report

### Target user:

This template allows users to create DAST gitlab reports for FOD.

### Add on implementation should go in:

* before_script
* after_script

### See example/s:

* Fod-Dast-Generate-Report: [Sample usage code](../gitlab-ci/Fod-Dast-Generate-Report.yml) and [Documentation](../gitlab-ci#example-fod-dast-generate-report)

### Variable/s to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|FOD_RELEASE| Y | Release ID for your FOD application|

### CICD Settings/Variables to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|FOD_USERNAME| Y | Username of your service account|
|FOD_PAT| Y | Personal access token of your service account to run SAST/DAST scan|

### Known issue/s:
NA

### Reference/s:
NA

## File: [.gitlab-ci-sonarqube.yml](.gitlab-ci-sonarqube.yml)

### Template: .sonarqube-scan

### Target user:

This template allows user to perform Sonarqube scan of your code using the command 'sonar-scanner'.
The SonarScanner is the scanner to use when there is no specific scanner for your build system.

### Add on implementation should go in:

* before_script
* after_script

### See example/s:

* Nexus-Pull-Scan-And-Publish-NPM: [Sample usage code](../gitlab-ci/Nexus-Pull-Scan-And-Publish-NPM.yml) and [Documentation](../gitlab-ci#example-nexus-pull-scan-and-publish-npm)
* [supporting-apps/nodejs-simple-library](../supporting-apps/nodejs-simple-library)

### Variable/s to set:
|Key             | Required | Description|
|----------------|-----------|-----------|
|SONAR_PROJECTKEY  | Y | Sonarqube project key.|
|SCAN_DIR | N | Directory to be scanned. If no directory is specified, defaults to '.' which is the current working directory. |
|SONARQUBE_URL  | N | Sonarqube URL for either community or developer edition. Override with $SONARQUBE_DEVELOPER_URL if not using default community edition.|
|QUALITY_GATE_WAIT | N | Default to 'true'. If set to 'true', the pipeline will wait for the quality gate status until it is available. This will increase the pipeline duration.|
|SONAR_OPT_ARG | N | For setting optional arguments, for example "-Dsonar.ws.timeout=60". Please refer to [SonarScanner](https://docs.sonarqube.org/latest/analyzing-source-code/scanners/sonarscanner/) documentation for more information. |


### CICD Settings/Variables to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|SONAR_TOKEN | Y | Sonarqube token to be used for running analyses.|

### Known issue/s:
NA

### Reference/s:
* [SonarScanner](https://docs.sonarqube.org/latest/analysis/scan/sonarscanner/)

### Template: .sonarqube-scan-maven

### Target user:

This template allows user to perform Sonarqube scan of Java application code using the Maven goal 'mvn verify sonar:sonar'.

### Add on implementation should go in:

* before_script
* after_script

### See example/s:

* Nexus-Pull-And-Publish-MVN: [Sample usage code](../gitlab-ci/Nexus-Pull-And-Publish-MVN.yml) and [Documentation](../gitlab-ci#example-nexus-pull-and-publish-mvn)
* [supporting-apps/maven-simple-app](../supporting-apps/maven-simple-app)

### Variable/s to set:
|Key             | Required | Description|
|----------------|-----------|-----------|
|SONAR_PROJECTKEY  | Y | Sonarqube project key.|
|SCAN_DIR | N | Directory to be scanned. If no directory is specified, defaults to '.' which is the current working directory. |
|SONARQUBE_URL  | N | Sonarqube URL for either community or developer edition. Override with $SONARQUBE_DEVELOPER_URL if not using default community edition.|
|QUALITY_GATE_WAIT | N | Default to 'true'. If set to 'true', the pipeline will wait for the quality gate status until it is available. This will increase the pipeline duration. |
|SONAR_OPT_ARG | N | For setting optional arguments, for example "-Dsonar.ws.timeout=60". Please refer to [SonarScanner for Maven](https://docs.sonarqube.org/latest/analyzing-source-code/scanners/sonarscanner-for-maven/) documentation for more information. |

### CICD Settings/Variables to set:
|Key             | Required | Description|
|----------------|-----------|-----------|
|SONAR_TOKEN | Y | Sonarqube token to be used for running analyses.|

### Known issue/s:
NA

### Reference/s:
* [SonarScanner for Maven](https://docs.sonarqube.org/latest/analysis/scan/sonarscanner-for-maven/)

### Template: .sonarqube-scan-dotnet

### Target user:

This template allows user to perform Sonarqube scan of .NET core application code using 'dotnet-sonarscanner' command.

### Add on implementation should go in:

* script

### See example/s:

* Nexus-Pull-And-Publish-NuGet: [Sample usage code](../gitlab-ci/Nexus-Pull-And-Publish-NuGet.yml) and [Documentation](../gitlab-ci#example-nexus-pull-and-publish-nuget)
* [supporting-apps/dotNet-core-console-project](../supporting-apps/dotNet-core-console-project)

### Variable/s to set:
|Key             | Required | Description|
|----------------|-----------|-----------|
|SONAR_PROJECTKEY  | Y | Sonarqube project key.|
|SCAN_DIR | N | Directory to be scanned. If no directory is specified, defaults to '.' which is the current working directory. |v
|SONARQUBE_URL  | N | Sonarqube URL for either community or developer edition. Override with $SONARQUBE_DEVELOPER_URL if not using default community edition.|
|QUALITY_GATE_WAIT | N | Default to 'true'. If set to 'true', the pipeline will wait for the quality gate status until it is available. This will increase the pipeline duration.|
|SONAR_OPT_ARG | N | For setting optional arguments, for example "/d:sonar.ws.timeout=60". Please refer to [SonarScanner for .NET](https://docs.sonarqube.org/latest/analysis/scan/sonarscanner-for-msbuild/) documentation for more information. |

### CICD Settings/Variables to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|SONAR_TOKEN | Y | Sonarqube token to be used for running analyses.|

### Known issue/s:
* Should the after_script fails, job status will be 'passed'. This is a design bug that has been raised to GitLab for workarounds.

### Reference/s:
* [SonarScanner for .NET](https://docs.sonarqube.org/latest/analysis/scan/sonarscanner-for-msbuild/)

### Template: .sonarqube-scan-dotnet-framework

### Target user:

This template allows user to perform Sonarqube scan of .NET Framework application code using 'SonarScanner.MSBuild.exe' command.

### Add on implementation should go in:

* script

### See example/s:

* Nexus-Pull-And-Publish-NuGet-Windows: [Sample usage code](../gitlab-ci/Nexus-Pull-And-Publish-NuGet-Windows.yml) and [Documentation](../gitlab-ci#example-nexus-pull-and-publish-nuget-windows)
* [supporting-apps/dotNet-framework-console-project](../supporting-apps/dotNet-framework-console-project)

### Variable/s to set:
|Key             | Required | Description|
|----------------|-----------|-----------|
|SONAR_PROJECTKEY  | Y | Sonarqube project key.|
|SCAN_DIR | N | Path to the directory containing the dotnet framework solution or project file. If no directory is specified, defaults to '.' which is the current working directory. |
|SONARQUBE_URL  | N | Sonarqube URL for either community or developer edition. Override with $SONARQUBE_DEVELOPER_URL if not using default community edition.|
|QUALITY_GATE_WAIT | N | Default to 'true'. If set to 'true', the pipeline will wait for the quality gate status until it is available. This will increase the pipeline duration.|
|SONAR_OPT_ARG | N | For setting optional arguments, for example "/d:sonar.ws.timeout=60". Please refer to [SonarScanner for .NET Framework](https://docs.sonarqube.org/latest/analysis/scan/sonarscanner-for-msbuild/) documentation for more information. |

### CICD Settings/Variables to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|SONAR_TOKEN | Y | Sonarqube token to be used for running analyses.|

### Known issue/s:
* Should the after_script fails, job status will be 'passed'. This is a design bug that has been raised to GitLab for workarounds.
* Windows runners are required to run this example.

### Reference/s:
* [SonarScanner for .NET Framework](https://docs.sonarqube.org/latest/analysis/scan/sonarscanner-for-msbuild/)

### Template: .sonarqube-output-report

### Target user:

This template allows users to create SAST gitlab reports for Sonarqube scan. This template will only retrieve Unresolved Issues (Bug, Vulnerability and Code Smell) in your Sonarqube project. This template will not retrieve any Security Hotspots in your Sonarqube project.

### Add on implementation should go in:

* before_script
* after_script

### See example/s:

* Nexus-Pull-Scan-And-Publish-NPM: [Sample usage code](../gitlab-ci/Nexus-Pull-Scan-And-Publish-NPM.yml) and [Documentation](../gitlab-ci#example-nexus-pull-scan-and-publish-npm)
* [supporting-apps/nodejs-simple-library](../supporting-apps/nodejs-simple-library)
* Nexus-Pull-And-Publish-MVN: [Sample usage code](../gitlab-ci/Nexus-Pull-And-Publish-MVN.yml) and [Documentation](../gitlab-ci#example-nexus-pull-and-publish-mvn)
* [supporting-apps/maven-simple-app](../supporting-apps/maven-simple-app)
* Nexus-Pull-And-Publish-NuGet: [Sample usage code](../gitlab-ci/Nexus-Pull-And-Publish-NuGet.yml) and [Documentation](../gitlab-ci#example-nexus-pull-and-publish-nuget)
* [supporting-apps/dotNet-core-console-project](../supporting-apps/dotNet-core-console-project)
* Nexus-Pull-And-Publish-NuGet-Windows: [Sample usage code](../gitlab-ci/Nexus-Pull-And-Publish-NuGet-Windows.yml) and [Documentation](../gitlab-ci#example-nexus-pull-and-publish-nuget-windows)
* [supporting-apps/dotNet-framework-console-project](../supporting-apps/dotNet-framework-console-project)

### Variable/s to set:
|Key             | Required | Description|
|----------------|-----------|-----------|
|SONAR_PROJECTKEY  | Y | Sonarqube project key.|
|SONARQUBE_URL  | N | Sonarqube URL for either community or developer edition. Override with $SONARQUBE_DEVELOPER_URL if not using default community edition.|
|BRANCH_NAME  | N | Branch name of your Sonarqube Project (Sonarqube developer edition only) that is defined in the SONAR_OPT_ARG of your SonarQube scan job (refer to examples above). Declare only either BRANCH_NAME or PULL_REQUEST_ID but not both.|
|PULL_REQUEST_ID  | N | Pull request id of your Sonarqube Project (Sonarqube developer edition only) that is defined in the SONAR_OPT_ARG of your SonarQube scan job (refer to examples above). Declare only either BRANCH_NAME or PULL_REQUEST_ID but not both.|

### CICD Settings/Variables to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|SONAR_TOKEN | Y | Sonarqube token to be used for running analyses.|

### Known issue/s:
* NA

### Reference/s:
* [Gitlab SAST report format](https://gitlab.com/gitlab-org/security-products/security-report-schemas/-/blob/master/dist/sast-report-format.json)
* [Gitlab Schema versions](https://gitlab.com/gitlab-org/gitlab/-/tree/master/ee/lib/ee/gitlab/ci/parsers/security/validators/schemas)

## File: [.gitlab-ci-checksum-verify.yml](.gitlab-ci-checksum-verify.yml)

### Template: .verify-maven-artefact

### Target user:

This template allows users to pass / fail a pipeline by matching the MD5 checksum of a remote Nexus Repo artefact with a supplied one (OUTPUT_ARTEFACT).

### Add on implementation should go in:

* after_script

### See example/s:

* Maven-Artefact-Checksum-Verification: [Sample usage code](../gitlab-ci/Maven-Artefact-Checksum-Verification.yml) and [Documentation](../gitlab-ci#example-maven-artefact-checksum-verification)
* [supporting-apps/maven-simple-app](../supporting-apps/maven-simple-app)

### Variable/s to set:
|Key             | Required | Description|
|----------------|-----------|-----------|
|OUTPUT_ARTEFACT| Y |Path of original build artefact to be used to checksum verify artefact from Nexus Repo.|
|NEXUSREPO_REPO_GROUP_ID| Y | Directory structure storing your artefact specified like Java's package name rules.|
|ARTEFACT_ID| Y |Artefact id.|
|ARTEFACT_PACKAGE| Y |Artefact package. Common values - jar/war. |
|NEXUSREPO_REPO_ID| Y |Nexus repo name that your team uses.|
|ARTEFACT_VERSION| Y |Artefact version.|

### CICD Settings Variable/s to set:
|Key             | Required | Description|
|----------------|-----------|-----------|
|NEXUS_REPO_USERNAME | Y | Service account username required in settings.yml to authenticate with Nexus Repo.|
|NEXUS_REPO_PASSWORD | Y |Service account password required in settings.yml to authenticate with Nexus Repo.|

### Known issue/s:
NA

### Reference/s:
NA

### Template: .verify-artefact-checksum

### Target user:

This template compares the MD5 Checksum of deployment artefact (DEPLOY_ARTEFACT) against that of a build artefact (OUTPUT_ARTEFACT). Mismatch of checksums will fail the pipeline. The usage of it expects a supplied DEPLOY_ARTEFACT as opposed to Docker and Maven variations which take care of pulling the artefact to verify.

### Add on implementation should go in:

* before_script
* after_script

### See example/s:

NA

### Variable/s to set:
|Key             | Required | Description|
|----------------|-----------|-----------|
|OUTPUT_ARTEFACT| Y |Path of artefact to be used to verify DEPLOY_ARTEFACT (Original file).|
|DEPLOY_ARTEFACT| Y |Path of artefact to verify against  OUTPUT_ARTEFACT (To verify).|

### CICD Settings/Variables to set:
NA

### Known issue/s:
NA

### Reference/s:
NA

## File: [.gitlab-ci-postman.yml](.gitlab-ci-postman.yml)

### Template: .run-postman-api-test

### Target user:

This template allows users to run API testing using Postman (newman CLI) with test reports generated inside reports folder.

 ### Add on implementation should go in:

* before_script
* after_script

### See example/s:

* Postman-Test-And-Report: [Sample usage code](../gitlab-ci/Postman-Test-And-Report.yml) and [Documentation](../gitlab-ci#example-postman-test-and-report)
* [supporting-apps/postman-api-testcollection](../supporting-apps/postman-api-testcollection)

### Variable/s to set:
|Key             |Required |Description|
|----------------|-----------|-----------|
|POSTMAN_TEST_TARGET | Y | Path of Postman collection JSON test file relative to $POSTMAN_WORKING_DIR E.g. demo_api_tests.json |
|POSTMAN_REPORT_NAME | Y | Name of the report without extension. E.g. apitestreport  <br /> E.g. if the name is "apitestreport", the report files will be apitestreport.html and apitestreport.xml. <br /> Limit to alphanumeric, hyphens and underscores for the report name (no spaces allowed). <br /> The reports will be stored in $POSTMAN_WORKING_DIR/reports e.g. ./reports.  |
|POSTMAN_WORKING_DIR | N| Location of Postman collection JSON test file. <br /> If no directory is specified, defaults to '.' which is the current working directory. |
|POSTMAN_MISC_OPTS | N | Newman command options and arguments. Refer to "Newman Command Options" in References. E.g --silent|

### CICD Settings/Variables to set:
NA

### Known issue/s:
NA

### Reference/s:
* [Postman](https://www.postman.com/)
* [Newman Command Options](https://learning.postman.com/docs/running-collections/using-newman-cli/newman-options/)

## File: [.gitlab-ci-gitlab-api.yml](.gitlab-ci-gitlab-api.yml)

### Template: .generate-changelog

### Target user:

This template allows users to use GitLab API to generate changelog for release management. 

### Add on implementation should go in:

* after_script

### See example/s:

* .release-prep: [Sample usage code](.gitlab-ci-release-management.yml) and [Documentation](#template-release-prep)

### Variable/s to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|BRANCH | Y | Branch to generate changelog for. It is also the branch that the resultant changelog will be committed to. |
|PROJECT_ID | N | Project ID of the project (contains BRANCH) to commit the changelog to. Defaults to `$CI_PROJECT_ID`. |

### CICD Settings/Variables to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|TO_VERSION | Y | Version tag to use that matches "v1.2.3". An existing lower version tag is required. See [explanation](https://docs.gitlab.com/ee/api/repositories.html#requirements-for-from-attribute) ("Git tag of the last stable version that came before the version specified."). |
|TOKEN| Y | Gitlab API access token with minimally read and write api permissions to project.|

### Known issue/s:
NA

### Reference/s:
* [Changelog Entries](https://docs.gitlab.com/ee/development/changelog.html)
* [Add Changelog data to a Changelog file](https://docs.gitlab.com/ee/api/repositories.html#add-changelog-data-to-a-changelog-file)
* [Requirements for `from` attribute](https://docs.gitlab.com/ee/api/repositories.html#requirements-for-from-attribute)

### Template: .create-mr

### Target user:

This template allows users to use GitLab API to create merge request. 

### Add on implementation should go in:

* after_script

### See example/s:

* .release-prep: [Sample usage code](.gitlab-ci-release-management.yml) and [Documentation](#template-release-prep)

### Variable/s to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|BRANCH | Y | Source branch. |
|TARGET_BRANCH | Y | Target branch. |
|PROJECT_ID | N | Project ID of the project (contains BRANCH and TARGET_BRANCH) to create a merge request. Defaults to `$CI_PROJECT_ID`. |
|MR_TITLE| N | Merge Request Title. Defaults to `Changelog for release version $TO_VERSION`. |
|MR_DESCRIPTION | N | Merge Request Description. Defaults to `# Do not merge MR here.<br><br> Instructions: <br><br><h3>1. Review the CHANGELOG.md changes.</h3><h3>2. Approve / Reject (Ignore) the MR. If approving, go to 3.</h3><h3>3. Proceed the release pipeline job. It will merge MR and tag release.</h3><br>** Should the MR is merged here by accident, it is OK. You just need to do the tag release manually. **`. |

### CICD Settings/Variables to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|TOKEN| Y | Gitlab API access token with minimally read and write api permissions to project.|

### Known issue/s:
NA

### Reference/s:
* [Create MR](https://docs.gitlab.com/ee/api/merge_requests.html#create-mr)

### Template: .merge-mr

### Target user:

This template allows users to use Gitlab API to merge a merge request.

### Add on implementation should go in:

* after_script

### See example/s:

* .approve-release: [Sample usage code](.gitlab-ci-release-management.yml) and [Documentation](#template-approve-release)

### Dependencies:
* A Merge Request branch should be created first, you may consider using [.create-branch from .gitlab-ci-release-management.yml](.gitlab-ci-release-management.yml) or [.update-version-in-file-as-commit from .gitlab-ci-gitlab-api.yml](.gitlab-ci-gitlab-api.yml) to create a Merge Request branch.
* A Merge Request should be created first, you may consider using [.create-mr from .gitlab-ci-gitlab-api.yml](.gitlab-ci-gitlab-api.yml) to create a Merge Request.

### Variable/s to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|PROJECT_ID | N | Project ID of the project (contains BRANCH and TARGET_BRANCH) to merge mr. Defaults to `$CI_PROJECT_ID`. |
|MR_IID| N |Internal ID of Merge Request. This value can be provided or as an artifact (MR_IID.cfg). This should be set if you use the template [.create-mr](#template-create-mr). |

### CICD Settings/Variables to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|TOKEN| Y | Gitlab API access token with minimally read and write api permissions to project.|

### Known issue/s:
NA

### Reference/s:
* [Get single MR](https://docs.gitlab.com/ee/api/merge_requests.html#get-single-mr)
* [Merge a merge request](https://docs.gitlab.com/ee/api/merge_requests.html#merge-a-merge-request)

### Template: .update-version-in-file-as-commit

### Target user:

This template allows users to use GitLab API to create new commit in BRANCH after replacing the last version tag in FILE with the latest version (TO_VERSION).

### Add on implementation should go in:

* after_script

### See example/s:

* .release-prep: [Sample usage code](.gitlab-ci-release-management.yml) and [Documentation](#template-release-prep)

### Dependencies:
* A first release tag. You may create it via GUI or [git push a tag to your repository](https://docs.gitlab.com/ee/topics/git/tags.html).

### Variable/s to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|BRANCH | Y | Branch to update FILE. |
|PROJECT_ID | N | Project ID of the project (contains BRANCH) to commit the change in README.md file to. Defaults to `$CI_PROJECT_ID`. |
|FILE | N | File name and its path. Defaults to `README.md`. |
|COMMIT_MSG | N | Commit message to update version in file, such as README.md. Defaults to `Update current version to $TO_VERSION in $FILE`. |

### CICD Settings/Variables to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|TO_VERSION | Y | Release version and tag name that matches "v1.2.3". |
|TOKEN| Y | Gitlab API access token with minimally read and write api permissions to project.|

### Known issue/s:
NA

### Reference/s:
* [Create a release when a git tag is created](https://docs.gitlab.com/ee/user/project/releases/release_cicd_examples.html#create-a-release-when-a-git-tag-is-created)
* [List project repository tags](https://docs.gitlab.com/ee/api/tags.html#list-project-repository-tags)
* [Create a commit with multiple files and actions](https://docs.gitlab.com/ee/api/commits.html#create-a-commit-with-multiple-files-and-actions)

### Template: .create-release-api

### Target user:

This template allows users to use GitLab API to create a release under project's Deployments > Environments.

### Add on implementation should go in:

* after_script

### See example/s:
NA

### Variable/s to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|PROJECT_ID | N | Project ID of the project to create a release. Defaults to `$CI_PROJECT_ID`. |
|RELEASE_NAME | N | Release Name. Defaults to `$CI_PROJECT_NAME Release ${TO_VERSION}`. |
|RELEASE_DESCRIPTION | N | Release Description. Defaults to `Release ${TO_VERSION}<br>See [Changelog](./CHANGELOG.md) for changes.`. |

### CICD Settings/Variables to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|TO_VERSION | Y | Release version and tag name that matches "v1.2.3". |
|TOKEN| Y | Gitlab API access token with minimally read and write api permissions to project.|

### Known issue/s:
NA

### Reference/s:
* [Create a release](https://docs.gitlab.com/ee/api/releases/#create-a-release)

## File: [.gitlab-ci-release-management.yml](.gitlab-ci-release-management.yml)

### Template: .check-release-version-syntax

### Target user:

This template allows users to check on release version syntax to match vX.X.X where X is made of digit/s.

### Add on implementation should go in:

* after_script

### See example/s:

* .release-prep: [Sample usage code](.gitlab-ci-release-management.yml) and [Documentation](#template-release-prep)

### Variable/s to set:
NA

### CICD Settings/Variables to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|TO_VERSION | Y | Release version and tag name that matches "v1.2.3". |

### Known issue/s:
NA

### Reference/s:
NA

### Template: .create-branch

### Target user:

This template allows users to create a branch.

### Add on implementation should go in:

* after_script

### See example/s:
NA

### Variable/s to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|BRANCH | Y | Name of branch to create. |

### CICD Settings/Variables to set:
NA

### Known issue/s:
NA

### Reference/s:
NA

### Template: .create-tag

### Target user:

This template allows users to perform git tag.

### Add on implementation should go in:

* after_script

### See example/s:

* .approve-release: [Sample usage code](.gitlab-ci-release-management.yml) and [Documentation](#template-approve-release)

### Variable/s to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|TARGET_BRANCH | Y | Branch to add git tag. |

### CICD Settings/Variables to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|TO_VERSION | Y | Release version and tag name that matches "v1.2.3". |

### Known issue/s:
NA

### Reference/s:
* [Git Basics - Tagging](https://git-scm.com/book/en/v2/Git-Basics-Tagging)

### Template: .create-release

### Target user:

This template allows users to create a release using release keyword in project's Deployments > Environments.

### Add on implementation should go in:

* before_script
* after_script

### See example/s:

* .approve-release: [Sample usage code](.gitlab-ci-release-management.yml) and [Documentation](#template-approve-release)

### Variable/s to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|RELEASE_NAME | N | Release Name. Defaults to `$CI_PROJECT_NAME Release ${TO_VERSION}`. |
|RELEASE_DESCRIPTION | N | Release Description. Defaults to `Release ${TO_VERSION}<br>See [Changelog](./CHANGELOG.md) for changes.`. |

### CICD Settings/Variables to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|TO_VERSION | Y | Release version and tag name that matches "v1.2.3". |

### Known issue/s:
NA

### Reference/s:
* [GitLab release keyword](https://docs.gitlab.com/ee/ci/yaml/#release)

### Template: .release-prep

### Target user:

This template allows users to prepare a release that involves generating changelog then raising a merge request to approve of the changes in changelog before release. Preferably to be used in conjunction with [.approve-release](#template-approve-release) and [.release-prep-revert](#template-release-prep-revert).

### Add on implementation should go in:
NA

### See example/s:

* GitLab-Release-Management: [Sample usage code](../gitlab-ci/GitLab-Release-Management.yml) and [Documentation](../gitlab-ci#example-gitlab-release-management)

### Variable/s to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|BRANCH | Y | Source branch; the branch to commit the changelog changes to and to be deleted in after_script.  |
|TARGET_BRANCH | Y | Target branch. |
|PROJECT_ID | N | Project ID of the project to prep release. Defaults to `$CI_PROJECT_ID`. |
|MR_TITLE| N | Merge Request Title. Defaults to `Changelog for release version $TO_VERSION`. |
|MR_DESCRIPTION | N | Merge Request Description. Defaults to `# Do not merge MR here.<br><br> Instructions: <br><br><h3>1. Review the CHANGELOG.md changes.</h3><h3>2. Approve / Reject (Ignore) the MR. If approving, go to 3.</h3><h3>3. Proceed the release pipeline job. It will merge MR and tag release.</h3><br>** Should the MR is merged here by accident, it is OK. You just need to do the tag release manually. **`. |
|FILE | N | File name and its path. Defaults to `README.md`. |
|COMMIT_MSG | N | Commit message to update version in file, such as README.md. Defaults to `Update current version to $TO_VERSION in $FILE`. |

### CICD Settings/Variables to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|TO_VERSION | Y | Release version and tag name that matches "v1.2.3". |
|TOKEN| Y | Gitlab API access token with minimally read and write api permissions to project.|

### Known issue/s:
* If merge request cleanup in after_script failed, job status will be 'passed'. This is a design bug that has been raised to GitLab for workarounds.

### Reference/s:
* [Changelog Entries](https://docs.gitlab.com/ee/development/changelog.html)
* [Add Changelog data to a Changelog file](https://docs.gitlab.com/ee/api/repositories.html#add-changelog-data-to-a-changelog-file)
* [Create MR](https://docs.gitlab.com/ee/api/merge_requests.html#create-mr)
* [Delete a merge request](https://docs.gitlab.com/ee/api/merge_requests.html#delete-a-merge-request)
* [Create a release when a git tag is created](https://docs.gitlab.com/ee/user/project/releases/release_cicd_examples.html#create-a-release-when-a-git-tag-is-created)
* [List project repository tags](https://docs.gitlab.com/ee/api/tags.html#list-project-repository-tags)
* [Create a commit with multiple files and actions](https://docs.gitlab.com/ee/api/commits.html#create-a-commit-with-multiple-files-and-actions)

### Template: .approve-release

### Target user:
 
This template allows users to perform a release (from [.release-prep](#template-release-prep)) which will do the following:
1. Merge a release merge request after approval.
2. Tag latest commit on target branch with version provided.
3. Create a release under project's "Deployments > Releases".

Preferably to be used in conjunction with [.release-prep](#template-release-prep) and [.release-prep-revert](#template-release-prep-revert).

### Add on implementation should go in:

* after_script

### See example/s:

* GitLab-Release-Management: [Sample usage code](../gitlab-ci/GitLab-Release-Management.yml) and [Documentation](../gitlab-ci#example-gitlab-release-management)

### Dependencies:
* [.release-prep](#template-release-prep)

### Variable/s to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|TARGET_BRANCH | Y | Branch to add git tag. |
|PROJECT_ID | N | Project ID of the project to merge mr. Defaults to `$CI_PROJECT_ID`. |
|RELEASE_NAME | N | Release Name. Defaults to `$CI_PROJECT_NAME Release ${TO_VERSION}`. |
|RELEASE_DESCRIPTION | N | Release Description. Defaults to `Release ${TO_VERSION}<br>See [Changelog](./CHANGELOG.md) for changes.`. |
|MR_IID| N |Internal ID of Merge Request. This value can be provided or as an artifact (MR_IID.cfg). This should be set if you use the template [.release-prep](#template-release-prep). |

### CICD Settings/Variables to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|TO_VERSION | Y | Release version and tag name that matches "v1.2.3". |
|TOKEN| Y | Gitlab API access token with minimally read and write api permissions to project.|

### Known issue/s:
NA

### Reference/s:
* [Get single MR](https://docs.gitlab.com/ee/api/merge_requests.html#get-single-mr)
* [Merge a merge request](https://docs.gitlab.com/ee/api/merge_requests.html#merge-a-merge-request)
* [Git Basics - Tagging](https://git-scm.com/book/en/v2/Git-Basics-Tagging)

### Template: .release-prep-revert

### Target user: 

This template allows users to revert a release preparation [.release-prep](#template-release-prep) that creates a merge request and source branch.  Used in conjunction with [.release-prep](#template-release-prep) and in the event during cleanup when the release merge request has not been approved / has been rejected.

### Add on implementation should go in:

* after_script

### See example/s:

* GitLab-Release-Management: [Sample usage code](../gitlab-ci/GitLab-Release-Management.yml) and [Documentation](../gitlab-ci#example-gitlab-release-management)

### Dependencies:
* [.release-prep](#template-release-prep)

### Variable/s to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|PROJECT_ID | N | Project ID of the project (contains BRANCH and TARGET_BRANCH) to delete the Merge Request Branch. Defaults to `$CI_PROJECT_ID`. |
|MR_IID| N |Internal ID of Merge Request. This value can be provided or as an artifact (MR_IID.cfg). This should be set if you use the template [.release-prep](#template-release-prep). |

### CICD Settings/Variables to set:
|Key             |Required | Description|
|----------------|-----------|-----------|
|TOKEN| Y | Gitlab API access token with minimally read and write api permissions to project.|

### Known issue/s:
NA

### Reference/s:
* [Delete a merge request](https://docs.gitlab.com/ee/api/merge_requests.html#delete-a-merge-request)

## File: [.gitlab-ci-download-from-nexus-repo.yml](.gitlab-ci-download-from-nexus-repo.yml)

### Template: .download-from-nexus-repo

### Target user:

This template allows users to download artifacts from Nexus Repository by constructing a path based on the Nexus Repo Group ID and Nexus Repo ID.

### Add on implementation should go in:

* before_script
* after_script

### See example/s:

* Maven-Artefact-Checksum-Verification: [Sample usage code](../gitlab-ci/Maven-Artefact-Checksum-Verification.yml) and [Documentation](../gitlab-ci#example-maven-artefact-checksum-verification)
* [supporting-apps/maven-simple-app](../supporting-apps/maven-simple-app)

### Variable/s to set:
|Key             |Required |Description |
|----------------|------------|------------|
|NEXUSREPO_REPO_GROUP_ID | Y | Directory structure storing your artefact specified like Java's package name rules. |
|NEXUSREPO_REPO_ID | Y | Nexus Repo name that your team uses. |
|ARTEFACT_ID | Y | Artefact ID. |
|ARTEFACT_VERSION | Y | Artefact version. |
|ARTEFACT_PACKAGE | Y | Artefact package. Common values - jar/zip. |
|DOWNLOAD_PATH | Y | The path to download the artefacts to. |

### CICD Settings/Variables to set:
|Key             |Required |Description |
|----------------|------------|------------|
|NEXUS_REPO_USERNAME| Y | Service account username  required in settings.yml to authenticate with Nexus Repo. |
|NEXUS_REPO_PASSWORD | Y | Service account password required in settings.yml to authenticate with Nexus Repo. |

### Known issue/s:
NA

### Reference/s:
NA

## Shared contents:
### Base64 encoding:
To generate the token,
```
echo -n username:password | base64
```
Need to backslash to escape any special characters.
